# Machine Learning-Based Prediction of Electromagnetic Wave Propagation Paths from Lightning Storms

**MD FIROZ ALAM** — Enrollment No. 24123024 — PHC-351, Autumn 2026-27

Forecasts the ionospheric propagation environment over lightning-active regions from NASA data,
and converts the forecast into propagation quantities: foF2, MUF and one-hop ground range.

## Result

Held-out test period, chronological split, 12,074 forecasts:

| Lead time | Persistence RMSE | Model RMSE | R² | Skill |
|---|---|---|---|---|
| 1 h | 4.875 | 3.970 | 0.622 | +0.186 |
| 2 h | 5.565 | 3.915 | 0.592 | +0.296 |
| 6 h | 9.813 | **3.153** | **0.679** | **+0.679** |

RMSE in TECU. Best model: HistGradientBoostingRegressor. Skill = 1 − RMSE_model / RMSE_persistence.

## Setup

Requires Python 3.13 and a free NASA Earthdata Login (https://urs.earthdata.nasa.gov),
stored in `~/.netrc`:

    machine urs.earthdata.nasa.gov login YOUR_USERNAME password YOUR_PASSWORD

Then:

    python3 -m venv .venv
    .venv/bin/pip install -r requirements.txt

## Running the pipeline

Run in this order. Steps 1–4 download and prepare data; 5–7 train and produce results.

    ./src/download_tec.sh 2018 60 243 data/raw/tec   # 1. ionosphere maps (184 days)
    .venv/bin/python src/build_tec_cube.py           # 2. IONEX -> compressed netCDF cube
    .venv/bin/python src/build_flash_table.py        # 3. ISS-LIS lightning flashes
    .venv/bin/python src/build_omni.py               # 4. solar / geomagnetic drivers
    .venv/bin/python src/build_dataset.py            # 5. joined supervised table
    .venv/bin/python src/train.py                    # 6. compare 5 models x 3 horizons
    .venv/bin/python src/fit_best.py                 # 7. refit best model, save predictions
    .venv/bin/python src/figures.py                  # 8. all figures

Step 3 streams the LIS granules — it downloads one day, extracts the flash table, then deletes
the raw files — so peak disk use stays near 90 MB instead of the full ~5.6 GB archive.

## Checking the trained model

Command line, any location and time inside 2018-03-01 to 2018-09-01:

    .venv/bin/python src/predict.py --lat 28.6 --lon 77.2 --time "2018-08-20 12:00"
    .venv/bin/python src/predict.py --random 5 --horizon 2h

Or a local web interface:

    .venv/bin/python webapp/app.py        # then open http://127.0.0.1:5000

## Layout

    src/ionex.py              IONEX parser and TEC interpolation
    src/features.py           solar geometry, magnetic latitude, foF2 / MUF / hop range
    src/download_tec.sh       bulk download of UQRG ionosphere maps from NASA CDDIS
    src/download_lis.py       ISS-LIS granule download
    src/build_tec_cube.py     IONEX text -> single compressed netCDF cube
    src/build_flash_table.py  stream LIS granules -> per-day flash tables
    src/build_omni.py         OMNI2 -> hourly driver table
    src/build_dataset.py      join lightning, ionosphere and space weather
    src/train.py              model comparison against the persistence baseline
    src/fit_best.py           refit the best model, save test predictions
    src/figures.py            all report figures
    src/predict.py            command-line forecast for any point and time
    webapp/                   local web interface for the trained model
    notebooks/                the project notebook, executed
    docs/METHODOLOGY.md       design decisions and data-quality findings

## Note on the formulation

The target is TEC at `t + Δt`, not a quantity derived from present TEC. Deriving foF2 and MUF
from TEC and then predicting them *from* TEC would be circular — the label would be a
closed-form function of an input feature, and any model would report R² ≈ 1.0 while learning
nothing. The physics is applied to the forecast output, never used to build the label.
See `docs/METHODOLOGY.md` section 2.
