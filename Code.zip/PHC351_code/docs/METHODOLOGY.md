# Machine Learning-Based Prediction of Electromagnetic Wave Propagation Paths from Lightning Storms

**Student:** MD FIROZ ALAM — Enrollment 24123024
**Course:** PHC-351, Autumn 2026-27

---

## 1. Problem statement

Lightning discharges radiate electromagnetic energy across a very wide frequency range. The
low-frequency component (VLF/ELF) propagates to great distances inside the *Earth–ionosphere
waveguide*, where the upper boundary is formed by the ionised D and E layers. How far such a
signal reaches, and along which direction it is usable, is therefore controlled by the state of
the ionosphere at the time of the flash.

This project predicts that propagation environment over lightning-active regions, and converts
the prediction into physically meaningful propagation quantities.

## 2. Why the obvious formulation fails

The naive approach is:

1. take Total Electron Content (TEC) at the flash location,
2. compute the critical frequency `foF2`,
3. compute the maximum usable frequency and the one-hop skywave range,
4. train a model to predict (3) from features including (1).

**This is circular.** The label in step 3 is a closed-form, deterministic function of the input in
step 1. A model given TEC as a feature would simply relearn the algebra and report an
R² close to 1.0. The score would measure nothing about the physics and would not generalise.

Any reported accuracy from that design is an artefact of the setup, not a scientific result.

## 3. Formulation actually used

The problem is posed as a **forecast**, which breaks the circularity because the target at
time `t + Δt` is genuinely not observable at time `t`:

| | |
|---|---|
| **Unit of analysis** | One LIS lightning flash (location, time) |
| **Inputs** | Flash optical/geometric features; TEC history over `t-2h … t`; solar and geomagnetic drivers; solar zenith angle; magnetic latitude; time-of-day and seasonal harmonics |
| **Target** | Vertical TEC at the flash location at `t + Δt`, for Δt ∈ {1 h, 2 h, 6 h} |
| **Baseline** | Persistence — "TEC at `t + Δt` equals TEC at `t`" |
| **Physics layer** | Predicted TEC → `NmF2` → `foF2` → MUF → one-hop ground range, mapped geographically |

The physics appears as a **derived output layer**, not as the training label. This is the
key design decision of the project.

A model is only considered successful if it beats persistence. Persistence is a strong
baseline for ionospheric quantities and is the honest benchmark.

## 4. Data sources

| Dataset | Role | Access |
|---|---|---|
| **NASA ISS-LIS V3** (`isslis_v3_fin`), Quality Controlled Science Data | Lightning flashes — the sampling points | NASA GHRC via Earthdata Login |
| **UPC-IonSAT UQRG** rapid global ionosphere maps | TEC — history and target | NASA CDDIS via Earthdata Login |
| **NASA OMNI2** hourly | Solar/geomagnetic drivers: Kp, Ap, Dst, F10.7, sunspot number | NASA SPDF |

### Notes on the data, verified against the files themselves

- **ISS-LIS contains no propagation information.** The granules carry 22 flash-level variables,
  all optical or geometric: latitude, longitude, TAI93 time, radiance, footprint, duration,
  group and event counts, and several quality indices. There is no field strength, no
  frequency, no direction and no ray path. This is why the label must be constructed, and the
  project description is worded as lightning features "combined with relevant atmospheric or
  ionospheric parameters" rather than claiming LIS provides propagation paths.
- **TEC cadence.** The IGS final combined product (`igsg`) is **2-hourly** (13 maps/day). The
  15-minute product used here is UPC-IonSAT's rapid map (`uqrg`, 97 maps/day). The distinction
  matters and should be stated correctly.
- **IONEX quirk.** The format writes end-of-day midnight as hour **24**, which standard date
  parsers reject. The parser in `src/ionex.py` rolls this to 00:00 of the following day.

## 5. Physics of the output layer

Peak electron density from TEC, using an equivalent slab thickness `τ` (taken as ~300 km,
a standard mid-latitude approximation):

```
NmF2 ≈ TEC / τ
```

Critical frequency of the F2 layer, with `NmF2` in electrons·m⁻³ and `foF2` in Hz:

```
foF2 = 8.98 × sqrt(NmF2)
```

Maximum usable frequency for a path with ionospheric incidence angle `φ`:

```
MUF = foF2 / cos(φ)
```

One-hop ground range for reflection height `h` and Earth radius `R`:

```
D = 2 R · arccos( R / (R + h) · cos(elevation) )
```

These are reported as derived diagnostics of the forecast, with the slab-thickness
assumption stated explicitly as a limitation.

## 6. Pipeline

```
src/ionex.py             IONEX parser (TEC grids -> arrays, trilinear interpolation)
src/download_tec.sh      Bulk CDDIS download of UQRG maps
src/build_tec_cube.py    IONEX text -> single compressed netCDF cube (~13x smaller)
src/build_flash_table.py Stream LIS granules -> flash tables, delete raw (disk-bounded)
```

## 7. Limitations to state in the report

1. Slab thickness is assumed constant; in reality it varies with location, season and solar activity.
2. Vertical TEC from GIMs is itself a model product with its own error, not a direct measurement.
3. The Earth–ionosphere waveguide is governed by the D/E region at VLF, whereas TEC is dominated
   by the F2 layer. TEC is therefore a proxy for the propagation environment, not a direct
   measure of VLF reflection height.
4. LIS observes from the ISS and samples any location only intermittently, so coverage is not uniform.

---

## 8. Data-quality issues found and resolved

These were discovered by verifying processed data against freshly downloaded source files,
rather than assuming the pipeline was correct. Each is worth stating in the report.

### 8.1 IONEX hour-24 convention
The format writes end-of-day midnight as hour **24**, which `datetime` rejects outright.
Every file failed to parse until the parser was changed to roll `24:00` to `00:00` of the
following day.

### 8.2 Silent 1000× error in the time axis
`pandas` 3.x `DatetimeIndex` can carry **microsecond** resolution, so `.astype("int64")`
does not reliably return nanoseconds. Dividing by `1e9` therefore under-scaled every
timestamp by exactly 1000, placing the whole six-month series in January 1970. Conversion now
goes through an explicit `datetime64[s]` dtype. After the fix the series is gapless:
17,665 epochs, every one of the 17,664 intervals exactly 15 minutes.

### 8.3 Double application of `scale_factor`
The netCDF4 library applies a variable's `scale_factor` on **write** as well as on read.
Pre-multiplying values by 10 before assignment therefore stored `TEC × 100` under a
0.1 factor, inflating every value tenfold on read-back. Physical values are now handed to
the library directly and it performs the scaling.

### 8.4 Day-boundary duplicate epochs
Each UQRG daily file ends with a `24:00` map that duplicates the next day's `00:00` epoch.
These two are **not** equivalent: the `24:00` map is extrapolated beyond its daily solution
window. Comparing two freshly downloaded files for 2018-04-09 and 2018-04-10:

| statistic | value |
|---|---|
| max abs difference | **22.20 TECU** |
| mean abs difference | 1.31 TECU |
| 99th percentile | 8.40 TECU |

Deduplication therefore keeps the **last** occurrence, so each epoch comes from the file
whose own day it belongs to. The sort is stable to guarantee that ordering.

### 8.5 Verification result
After these fixes, the stored cube reproduces freshly downloaded source files **exactly**
(0.0000 TECU difference) at every interior epoch tested.

### 8.6 Slightly negative TEC values
The cube's minimum is **-3.7 TECU**. Negative vertical TEC is unphysical but is a known
artefact of the GIM inversion in low-signal regions. These are retained in the raw cube and
clipped at zero during feature construction; the choice is noted rather than hidden.
