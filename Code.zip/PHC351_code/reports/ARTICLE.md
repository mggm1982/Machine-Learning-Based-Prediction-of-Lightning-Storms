# Forecasting the Ionospheric Propagation Environment over Lightning-Active Regions: A Machine-Learning Study with NASA ISS-LIS, GNSS TEC and OMNI Data

**MD FIROZ ALAM**
Enrollment No. 24123024
Department of Physics, PHC-351, Autumn 2026-27

**Keywords:** ionosphere, total electron content, lightning, VLF propagation, machine learning, gradient boosting, space weather, foF2, maximum usable frequency

---

## Abstract

Lightning discharges radiate electromagnetic energy over a very wide frequency range. The
low-frequency component propagates to global distances within the Earth–ionosphere waveguide,
whose upper boundary is formed by the ionised upper atmosphere. The reach of such a signal,
and the highest frequency a given path will support, are therefore governed by the ionospheric
state at the time of the discharge.

This work forecasts that propagation environment over lightning-active regions using machine
learning applied to three public NASA datasets, and converts the forecast into the propagation
quantities of interest: the F2-layer critical frequency `foF2`, the maximum usable frequency
(MUF), and the one-hop ground range.

A central methodological point is addressed explicitly. Deriving `foF2` and MUF from Total
Electron Content (TEC) and then training a model to predict them *from* TEC is circular: the
label is a closed-form function of the input, and any model recovers R² ≈ 1.0 while learning
nothing about the physics. The problem is therefore posed as a forecast — predicting TEC at
`t + Δt`, which is genuinely unobservable at time `t` — with the physics applied to the
forecast output rather than used to construct the label.

Using 381,858 ISS-LIS lightning flashes, 17,665 fifteen-minute global ionosphere maps and
8,760 hourly solar/geomagnetic records spanning March–August 2018, five models were compared
against a persistence benchmark at 1-, 2- and 6-hour lead times on a strictly chronological
split. All five beat persistence at every lead time. Histogram gradient boosting performed
best, achieving **RMSE 3.15 TECU, R² 0.68 and a skill score of +0.68 at a 6-hour lead**, where
persistence attains R² = −2.11. Forecast skill *increases* with lead time, a consequence of
persistence decaying across the diurnal cycle while solar geometry does not.

Feature-importance analysis shows the model relying on the current ionospheric state at short
lead and switching to solar zenith angle at the target epoch at long lead, thereby recovering
the dominant physical driver without supervision. A case-by-case analysis qualifies the
headline result: at one-hour lead the model wins only 51.9% of individual cases and acts
primarily as a variance-reducer. Lightning activity was found **not** to be a useful predictor
of TEC, and this negative result is reported rather than omitted.

---

## 1. Introduction

A lightning stroke is a broadband electromagnetic source. Its very-low-frequency (VLF) and
extremely-low-frequency (ELF) components are guided between the conducting ground and the
lower ionosphere and can be detected many thousands of kilometres from the parent storm. The
upper wall of this waveguide is a plasma whose electron density varies strongly with local
time, season, latitude and geomagnetic activity. Consequently the propagation conditions for
lightning-generated radio signals are not fixed properties of geography but time-varying
functions of the state of the upper atmosphere.

Solar extreme-ultraviolet radiation ionises the upper atmosphere, producing free electrons
distributed through the D, E and F layers. A plasma reflects electromagnetic waves below its
characteristic plasma frequency and transmits those above it, so the ionosphere behaves as a
frequency-dependent mirror. Total Electron Content (TEC) — the integrated electron density in
a column of unit cross-section, measured in TECU where 1 TECU = 10¹⁶ electrons m⁻² — is the
standard scalar description of this medium.

This paper asks whether the ionospheric propagation environment above lightning-active regions
can be forecast several hours ahead from public satellite and ground-based observations, and
whether lightning activity itself carries predictive information about that environment.

## 2. Objectives and motivation

### 2.1 Objectives

1. Construct a machine-learning model that forecasts the ionospheric propagation environment
   over regions where lightning is occurring.
2. Pose the problem so that the result is scientifically defensible — specifically, not
   circular (Section 5.1).
3. Convert the forecast into physically meaningful propagation quantities: `foF2`, MUF and
   one-hop ground range.
4. Benchmark honestly against persistence and report failure modes alongside successes.
5. Use only public NASA data, with a reproducible pipeline.

### 2.2 Why the problem matters

- **VLF and HF communication.** Long-range and submarine communication links depend on the
  Earth–ionosphere waveguide; the usable frequency band shifts with ionospheric state.
- **Lightning geolocation.** VLF sferic networks locate strokes by time-of-arrival. Errors in
  assumed propagation conditions translate directly into position errors.
- **GNSS positioning.** Ionospheric delay is the dominant error source for single-frequency
  receivers; TEC forecasting is an operational space-weather product.
- **Aviation and polar HF.** Routes with thin satellite coverage still rely on HF propagation
  predictions.
- **Space-weather warning.** A geomagnetic storm alters TEC — and therefore all of the above —
  within hours.

## 3. Theory

### 3.1 The Earth–ionosphere waveguide

Below roughly 100 km the D and E regions provide sufficient conductivity to reflect VLF
signals, which then propagate with low attenuation between that ceiling and the ground. TEC,
however, is dominated by the F2 layer near 300 km altitude. TEC is therefore an indicator of
the overall ionisation state rather than a direct measurement of VLF reflection height — a
limitation returned to in Section 9.

### 3.2 From TEC to propagation quantities

Peak electron density is obtained from TEC using an equivalent slab thickness `τ`:

$$N_mF_2 \approx \frac{\text{TEC}}{\tau}$$

The plasma (critical) frequency follows from the standard relation, in which the coefficient
8.98 returns **hertz** when `NmF2` is expressed in m⁻³:

$$f_oF_2\,[\text{Hz}] = 8.98\sqrt{N_mF_2}$$

For an oblique path with angle of incidence `φ` at the reflecting layer, the maximum usable
frequency is

$$\text{MUF} = \frac{f_oF_2}{\cos\varphi}$$

and the one-hop ground range for take-off elevation `θ`, reflection height `h` and Earth radius
`R` is

$$D = 2R\left[\frac{\pi}{2} - \theta - \arcsin\!\left(\frac{R\cos\theta}{R+h}\right)\right]$$

Evaluated over the observed TEC range with `τ` = 300 km:

| TEC (TECU) | foF2 (MHz) | MUF at 5° (MHz) |
|---|---|---|
| 5 | 3.67 | 11.90 |
| 10 | 5.18 | 16.83 |
| 20 | 7.33 | 23.81 |
| 40 | 10.37 | 33.67 |
| 64 | 13.12 | 42.59 |

The one-hop ground range at 5° take-off and 300 km reflection height is 2,877 km. The implied
M-factor (MUF/`foF2`) of 3.25 is consistent with standard values for low take-off angles, and
the `foF2` range of 3.7–13.1 MHz matches observed mid-latitude values — both serve as
independent checks that the physics layer is correctly implemented.

## 4. Previous work

Two distinct bodies of work bear on this problem.

**Lightning and its radio signature.** Lightning mapping arrays locate discharge sources by
time-of-arrival of VLF/VHF radiation across multiple receivers, yielding three-dimensional
reconstructions of individual flashes; the techniques, their limitations and the prospects for
deep learning are reviewed in *Lightning Mapping: Techniques, Challenges, and Opportunities*
(arXiv:2006.00563). More directly relevant, Konan, Mishra and Lotz (2020, arXiv:2002.01244)
applied machine learning — including YOLO-based object detection — to the automatic detection
and characterisation of **whistlers**, VLF waves generated by lightning that propagate between
hemispheres along geomagnetic field lines, reporting misdetection and false-alarm rates below
15%. These establish both that the radio signature of lightning is routinely measurable and
that its propagation is governed by the ionosphere.

**Machine-learning forecasting of the ionosphere.** Cesaroni et al. (2020) developed a
neural-network model for global TEC forecasting, and Liu et al. (2020) applied deep learning
to the same problem. Subsequent work has adopted convolutional LSTM and transformer
architectures to forecast global TEC maps at lead times from one hour to several days. These
studies share a common framing: they forecast TEC globally and uniformly, driven by TEC
history and space-weather indices.

**Position of this work.** The present study differs in three respects. It samples
specifically at lightning locations rather than on a uniform global grid; it carries the
forecast through to propagation quantities rather than stopping at TEC; and it explicitly
tests whether lightning activity contributes predictive information about the ionospheric
state — a question the TEC-forecasting literature does not pose.

## 5. Method

### 5.1 Avoiding a circular formulation

The direct reading of the problem suggests the following pipeline: take TEC at the flash
location, compute `foF2`, compute MUF and one-hop range, and train a model to predict the
latter from features including TEC. This is circular. The label is a deterministic closed-form
function of an input feature, so a sufficiently flexible model simply recovers the algebra and
reports R² ≈ 1.0. Such a score is an artefact of the experimental design and carries no
information about the physical system.

The problem is therefore recast as a **forecast**, which breaks the circularity because the
target at `t + Δt` is not observable at `t`.

### 5.2 Formulation

| Element | Definition |
|---|---|
| Sample | one (TEC grid cell, 15-minute epoch) in which ISS-LIS observed lightning |
| Inputs | lightning features; TEC history to `t`; solar/geomagnetic drivers; solar geometry |
| Target | vertical TEC in that cell at `t + Δt`, for Δt ∈ {1 h, 2 h, 6 h} |
| Benchmark | persistence: TEC at `t + Δt` equals TEC at `t` |
| Physics | applied to the forecast output; never used to construct the label |

Solar zenith angle at the **target** epoch is included as a feature. This does not constitute
leakage: it is deterministic astronomy, computable arbitrarily far in advance. No quantity
derived from the target epoch's TEC enters the input set.

### 5.3 Data

| Dataset | Role | Volume |
|---|---|---|
| NASA ISS-LIS V3 Quality Controlled Science Data (`isslis_v3_fin`) | lightning flashes | 381,858 flashes |
| UPC-IonSAT UQRG rapid global ionosphere maps (NASA CDDIS) | TEC history and target | 17,665 maps |
| NASA OMNI2 hourly | Kp, ap, Dst, AE, F10.7, sunspot number | 8,760 records |

Period: 1 March – 31 August 2018, on a 2.5° × 5° grid at 450 km. Note that the IGS final
combined ionosphere product is 2-hourly; the 15-minute product used here is UPC-IonSAT's rapid
map (UQRG), at 97 maps per day.

**ISS-LIS contains no propagation information.** Its 22 flash-level variables — latitude,
longitude, time, radiance, footprint, duration, group and event counts, and quality indices —
are all optical or geometric. There is no field strength, frequency, direction or ray path.
This is precisely why the prediction target must be constructed rather than read from the file.

### 5.4 Feature construction

One sample is a (grid cell, 15-minute epoch) pair containing lightning. Aggregation is
essential: a single storm produces thousands of flashes within one cell in one epoch, and
retaining each flash as a separate row would place near-identical samples in both training and
test partitions. The 381,858 flashes aggregate to 26,883 samples.

Forty features in five groups: lightning activity (flash count, radiance statistics, footprint,
duration, group and event counts, oblongness); TEC history (at `t` and at −15 m, −30 m, −1 h,
−2 h, −3 h, plus the corresponding tendencies); spatial context (mean TEC of the eight
neighbouring cells and the local gradient); geometry (latitude, magnetic latitude, solar zenith
angle at `t` and `t + Δt`, local-time and seasonal harmonics); and space weather (Kp, ap, Dst,
AE, F10.7, sunspot number).

### 5.5 Validation design

The partition is strictly chronological — earliest 70% for training, the next 15% for
validation, and a final 15% test period untouched during model selection. Ionospheric fields
are strongly autocorrelated in space and time, so a random split would distribute neighbouring
15-minute samples across partitions and permit effective lookup of the targets. The test
period additionally contains the strongest geomagnetic storm of the interval, making the
reported figures conservative.

## 6. Results

### 6.1 Model comparison

Test-period performance (n ≈ 4,000 per horizon):

| Model | 1 h RMSE | 2 h RMSE | 6 h RMSE | 6 h R² | 6 h skill |
|---|---|---|---|---|---|
| Persistence | 4.875 | 5.565 | 9.813 | −2.105 | — |
| Ridge regression | 4.046 | 4.016 | 4.856 | 0.240 | +0.505 |
| Neural network (MLP) | 4.614 | 4.534 | 3.486 | 0.608 | +0.645 |
| Random Forest | 4.099 | 4.009 | 3.605 | 0.581 | +0.633 |
| XGBoost | 4.061 | 4.131 | 3.415 | 0.624 | +0.652 |
| **HistGradientBoosting** | **3.970** | **3.915** | **3.153** | **0.679** | **+0.679** |

RMSE in TECU; skill = 1 − RMSE_model / RMSE_persistence.

All five models beat persistence at every lead time. Skill increases with lead time, from
+0.19 at one hour to +0.68 at six hours. This is a physical rather than statistical result:
six hours spans a quarter of the diurnal cycle, so the persistence assumption degrades sharply
— reaching R² = −2.105, worse than predicting the sample mean — whereas a model with access to
solar geometry does not. An R² of 0.68 is a credible value; the circular formulation of
Section 5.1 would have produced ≈1.0.

### 6.2 Where the advantage originates

Aggregate RMSE conceals an important nuance:

| Lead | Model wins | Median abs error, model | Median, persistence | RMSE model | RMSE persistence |
|---|---|---|---|---|---|
| 1 h | 51.9% | 1.74 | 1.70 | 4.00 | 4.88 |
| 2 h | 57.4% | 2.05 | 2.40 | 3.97 | 5.57 |
| 6 h | **81.1%** | **1.67** | 6.10 | 3.11 | 9.81 |

At one-hour lead the model is only marginally better than chance on a case-by-case basis, and
its *typical* error slightly exceeds that of persistence. Its superior RMSE arises entirely
from suppressing large errors; at short lead it is best characterised as a variance-reducer
rather than an improved point forecast. At six hours this reverses decisively.

Restricting to the storm interval (Kp ≥ 5, n = 164 per horizon):

| Lead | Model RMSE | Persistence RMSE | Model wins |
|---|---|---|---|
| 1 h | 6.93 | 8.26 | 40.9% |
| 2 h | 7.70 | 9.03 | 46.3% |
| 6 h | 4.43 | 14.92 | 70.7% |

Errors approximately double under storm conditions and the model loses more often than it wins
at short lead, while retaining lower RMSE throughout for the same variance-suppression reason.

### 6.3 Learned feature importance

| 1-hour lead | importance | 6-hour lead | importance |
|---|---|---|---|
| neighbouring-cell TEC mean | 0.573 | **solar zenith angle at target epoch** | 0.185 |
| TEC at `t` | 0.135 | solar zenith angle at `t` | 0.122 |
| local-time cosine | 0.037 | TEC tendency over 2 h | 0.117 |
| day-of-year sine | 0.017 | local-time sine | 0.076 |
| solar zenith angle at target | 0.016 | TEC tendency over 1 h | 0.075 |

The ranking inverts between lead times. At short lead the model relies on the present
ionospheric state; at long lead solar geometry at the target epoch becomes the single most
important feature, followed by TEC tendency. The model recovers solar illumination as the
dominant physical driver without being supplied that relationship.

### 6.4 Negative result

No lightning feature appears among the important predictors at any lead time. Lightning
activity does not measurably influence TEC at these scales. The defensible claim is therefore
that this work forecasts the propagation environment **over lightning-active regions** — the
lightning observations define where and when the forecast is issued — rather than forecasting
that environment **from** lightning.

### 6.5 Storm case study

During the 26 August 2018 geomagnetic storm (Dst −176 nT, Kp 7.3), mean equatorial TEC
(|lat| ≤ 30°) rises sharply to ≈16.5 TECU before falling below its pre-storm level. This
positive-then-negative phase sequence is the classical storm-time ionospheric response, driven
first by storm-time electric fields lifting plasma and subsequently by changes in neutral
composition. Its reproduction directly from raw files confirms that the processing chain
preserves genuine geophysical signal.

### 6.6 Data-quality verification

Processed data was validated against freshly downloaded source files rather than assumed
correct. Four defects were identified and corrected: (i) the IONEX convention of writing
end-of-day midnight as hour 24, which standard date parsers reject; (ii) a silent factor-of-1000
error in the time axis arising because `pandas` 3.x `DatetimeIndex` may carry microsecond
resolution, placing the entire series in January 1970 without raising any exception; (iii)
double application of the netCDF4 `scale_factor`, which is applied on write as well as read;
and (iv) day-boundary duplicate epochs differing by up to 22.2 TECU, since each daily file's
24:00 map is extrapolated beyond its solution window. After correction the stored cube
reproduces freshly downloaded source files exactly (0.0000 TECU) at every interior epoch, and
the series is gapless: 17,665 epochs, all 17,664 intervals exactly 15 minutes.

## 7. Conclusions

1. A non-circular, physically meaningful machine-learning formulation of the problem was
   constructed entirely from public NASA data.
2. All five models beat the persistence benchmark; histogram gradient boosting achieved
   RMSE 3.15 TECU, R² 0.68 and skill +0.68 at six-hour lead.
3. Forecast skill increases with lead time, as persistence decays across the diurnal cycle
   while solar geometry does not.
4. The model independently recovered solar illumination as the dominant physical driver.
5. Forecast TEC was converted into `foF2`, MUF and one-hop ground range.
6. Lightning activity was found not to predict TEC — reported as a genuine negative result.

**Is the problem solved?** Substantially, with two qualifications stated openly. The title
refers to propagation *paths*; what is delivered is the propagation *environment* and the path
quantities derived from it, not ray-traced trajectories, which would require a D-region
electron-density profile and a ray-tracing model. And because lightning does not predict TEC,
the link between storm and forecast is geographic rather than causal.

## 8. Limitations

1. **TEC is an F2-region quantity while VLF waveguide propagation is governed by the D and E
   regions.** TEC is a proxy for the propagation environment, not a direct measure of VLF
   reflection height. This is the most significant caveat of the study.
2. Slab thickness is assumed constant at 300 km; in reality it varies with location, season
   and solar activity, so `foF2` and MUF inherit that systematic uncertainty.
3. Global ionosphere maps are themselves model products interpolated from a finite GNSS
   network. The processed cube's minimum of −3.6 TECU is unphysical and reflects inversion
   artefacts.
4. Coverage is limited to one season of one year. 2018 lay in deep solar minimum (mean
   F10.7 ≈ 70); solar-maximum conditions with several times higher TEC are untested.
5. ISS-LIS sampling is intermittent and restricted to ±55° latitude by the ISS orbit, so
   spatial coverage is non-uniform.
6. Lightning features contribute negligibly, as reported in Section 6.4.
7. At one-hour lead the model functions as a variance-reducer rather than a superior point
   forecast (Section 6.2).

## 9. Data and code availability

All data are public. ISS-LIS V3 is distributed by NASA GHRC DAAC; UQRG ionosphere maps by NASA
CDDIS; OMNI2 by NASA SPDF. Access to the first two requires a free NASA Earthdata Login. The
processing pipeline comprises twelve scripts covering download, parsing, feature construction,
training, evaluation and figure generation.

## References

1. NASA GHRC DAAC. *Quality Controlled Lightning Imaging Sensor (LIS) on International Space
   Station (ISS) Science Data V3* (`isslis_v3_fin`).
2. NASA CDDIS. *UPC-IonSAT UQRG rapid global ionosphere maps*, IONEX format.
3. NASA SPDF. *OMNI2 hourly solar wind and geomagnetic index dataset*.
4. *Lightning Mapping: Techniques, Challenges, and Opportunities.* arXiv:2006.00563.
5. Konan, O.J.E.Y., Mishra, A.K., Lotz, S. (2020). *Machine Learning Techniques to Detect and
   Characterise Whistler Radio Waves.* arXiv:2002.01244.
6. Cesaroni, C., Spogli, L., Aragón-Àngel, A., Fiocca, M., Dear, V., De Franceschi, G.,
   Romano, V. (2020). *Neural network based model for global Total Electron Content
   forecasting.* Journal of Space Weather and Space Climate, 10, 11.
7. Liu, L. et al. (2020). *Forecasting Global Ionospheric TEC Using Deep Learning Approach.*
   Space Weather, 18. doi:10.1029/2020SW002501.
8. Schaer, S., Gurtner, W., Feltens, J. (1998). *IONEX: The IONosphere Map EXchange Format
   Version 1.* Proceedings of the IGS Analysis Center Workshop.
9. Davies, K. (1990). *Ionospheric Radio.* Peter Peregrinus, London.
