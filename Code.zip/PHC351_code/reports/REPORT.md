# Machine Learning-Based Prediction of Electromagnetic Wave Propagation Paths from Lightning Storms

**MD FIROZ ALAM** — Enrollment No. 24123024
**PHC-351 — Autumn 2026-27**

---

## Abstract

Lightning radiates electromagnetic energy over a very wide frequency range. The
low-frequency component propagates to great distances inside the Earth–ionosphere waveguide,
where the upper boundary is formed by the ionised layers of the upper atmosphere. The reach
of such a signal, and the highest frequency for which a given path stays usable, are therefore
controlled by the ionospheric state at the moment of the discharge.

This project forecasts that propagation environment over lightning-active regions using
machine learning on three NASA datasets, and converts the forecast into the propagation
quantities implied by the title: the critical frequency `foF2`, the maximum usable frequency
(MUF), and the one-hop ground range.

Using 381,858 ISS-LIS lightning flashes, six months of 15-minute global ionosphere maps and
hourly solar/geomagnetic indices, five models were compared against a persistence benchmark
at 1-, 2- and 6-hour lead times. **All five beat persistence at every lead time.** Gradient
boosting was best, reaching **RMSE 3.11 TECU, R² 0.69 and a skill score of +0.68 at a
6-hour lead.** Forecast skill *increases* with lead time, a result that follows directly from
the underlying physics. Feature-importance analysis shows the model relying on the current
ionospheric state at short lead and switching to solar geometry at long lead — recovering the
correct physical driver without being told it.

---

## 1. Introduction and motivation

A lightning discharge is a broadband electromagnetic source. Its VLF and ELF components are
guided between the conducting ground and the lower ionosphere, and can be detected thousands
of kilometres from the storm. Because the upper wall of that waveguide is an ionised plasma,
the propagation conditions depend on the electron density above the storm — a quantity that
varies strongly with time of day, season, latitude and geomagnetic activity.

Predicting that environment therefore connects classical electromagnetic wave theory with
data-driven modelling, which is the stated aim of this project.

## 2. Problem formulation

### 2.1 Why the obvious approach is invalid

The natural reading of the project title suggests this pipeline:

1. take Total Electron Content (TEC) at the flash location,
2. compute the critical frequency `foF2` from it,
3. compute MUF and one-hop range from `foF2`,
4. train a model to predict (3) from features including (1).

**This is circular.** The label produced in step 3 is a closed-form deterministic function of
the input in step 1. Any reasonable model relearns the algebra and reports R² ≈ 1.0. The
resulting accuracy measures nothing about the physics and would not generalise. A reported
score from such a design is an artefact of the setup.

### 2.2 The formulation used

The task is posed as a **forecast**, which breaks the circularity because the target at
`t + Δt` is genuinely not observable at `t`.

| | |
|---|---|
| **Sample** | one (TEC grid cell, 15-minute epoch) containing observed lightning |
| **Inputs** | lightning features; TEC history to `t`; solar/geomagnetic drivers; solar zenith angle; magnetic latitude; local-time and seasonal harmonics |
| **Target** | vertical TEC at the same cell at `t + Δt`, for Δt ∈ {1 h, 2 h, 6 h} |
| **Benchmark** | persistence — TEC at `t + Δt` equals TEC at `t` |
| **Physics** | applied to the forecast *output*, never used to construct the label |

The solar zenith angle at the *target* epoch is included as a feature. This is not leakage:
it is pure astronomy, computable arbitrarily far in advance.

## 3. Data

| Dataset | Role | Access |
|---|---|---|
| NASA ISS-LIS V3 Quality Controlled Science Data (`isslis_v3_fin`) | lightning flashes | NASA GHRC, Earthdata Login |
| UPC-IonSAT UQRG rapid global ionosphere maps | TEC history and target | NASA CDDIS, Earthdata Login |
| NASA OMNI2 hourly | Kp, ap, Dst, AE, F10.7, sunspot number | NASA SPDF |

**Period:** 1 March – 31 August 2018, sampling LIS every third day.
**Volume:** 381,858 flashes; 17,665 TEC maps; 8,760 hourly driver records.

### 3.1 What ISS-LIS does and does not contain

LIS stores 22 flash-level variables — latitude, longitude, time, radiance, footprint,
duration, group and event counts, and several quality indices. **All of them are optical or
geometric. There is no field strength, no frequency, no direction and no ray path.** This is
the reason the prediction target had to be constructed rather than read from the file, and it
is why the project description refers to lightning features *combined with* ionospheric
parameters rather than claiming LIS provides propagation paths.

### 3.2 Notes on the ionosphere product

The IGS final combined ionosphere map (`igsg`) is **2-hourly**. The 15-minute product used
here is UPC-IonSAT's rapid map (`uqrg`), at 97 maps per day on a 2.5° × 5° grid at 450 km.
The distinction should be stated correctly: "15-minute NASA TEC" is accurate only for UQRG.

## 4. Method

### 4.1 Aggregation

One sample is a (grid cell, 15-minute epoch) pair containing lightning. A single storm can
produce thousands of flashes within one cell in one epoch; treating each flash as a row would
place near-identical samples in both training and test data and inflate every score. The
381,858 flashes aggregate to **26,883 samples**.

### 4.2 Features

| Group | Features |
|---|---|
| Lightning | flash count; mean/max/total radiance; mean and total footprint; mean duration; group and event counts; oblongness |
| TEC history | TEC at `t`; at −15 m, −30 m, −1 h, −2 h, −3 h; and the corresponding differences |
| Spatial | mean TEC of the 8 neighbouring cells; the local gradient |
| Geometry | latitude, |latitude|, magnetic latitude, solar zenith angle at `t` and at `t+Δt`, local-time and day-of-year harmonics |
| Space weather | Kp, ap, Dst, AE, F10.7, sunspot number |

### 4.3 Validation design

The split is **chronological, never random**: training on the earliest 70%, validation on the
next 15%, and a final 15% test period that is untouched during model selection. Ionospheric
fields are strongly autocorrelated in space and time, so a random split would effectively let
the model look up its answers.

## 5. Results

Test-period performance (final 15% of the period, n ≈ 4,000 per horizon):

| Model | 1 h RMSE | 1 h skill | 2 h RMSE | 2 h skill | 6 h RMSE | 6 h R² | 6 h skill |
|---|---|---|---|---|---|---|---|
| Persistence | 4.875 | — | 5.565 | — | 9.813 | −2.105 | — |
| Ridge | 4.046 | +0.170 | 4.016 | +0.278 | 4.856 | 0.240 | +0.505 |
| MLP | 4.614 | +0.054 | 4.534 | +0.185 | 3.486 | 0.608 | +0.645 |
| RandomForest | 4.099 | +0.159 | 4.009 | +0.280 | 3.605 | 0.581 | +0.633 |
| XGBoost | 4.061 | +0.167 | 4.131 | +0.258 | 3.415 | 0.624 | +0.652 |
| **HistGradientBoosting** | **3.970** | **+0.186** | **3.915** | **+0.296** | **3.153** | **0.679** | **+0.679** |

RMSE and MAE are in TECU. Skill score = `1 − RMSE_model / RMSE_persistence`.

### 5.1 Interpretation

**Every model beats persistence at every lead time**, so the forecast is doing real work.

**Skill grows with lead time** — from +0.19 at one hour to +0.68 at six hours. The reason is
physical rather than statistical: six hours is a quarter of a diurnal cycle, so "nothing
changes" becomes a badly wrong assumption, while a model that knows where the Sun will be does
not degrade. Persistence at six hours achieves R² = −2.105, i.e. it is worse than simply
predicting the mean.

**Gradient boosting wins**, which is the expected outcome for structured tabular data at this
scale. R² ≈ 0.6–0.69 is a believable figure; the circular formulation would have produced
R² ≈ 1.0 and meant nothing.

### 5.2 What the model learned

| 1-hour lead | importance | | 6-hour lead | importance |
|---|---|---|---|---|
| neighbouring-cell TEC mean | 0.573 | | **solar zenith angle at target time** | 0.185 |
| TEC now | 0.135 | | solar zenith angle now | 0.122 |
| local-time cosine | 0.037 | | TEC tendency over 2 h | 0.117 |
| day-of-year sine | 0.017 | | local-time sine | 0.076 |
| solar zenith angle at target | 0.016 | | TEC tendency over 1 h | 0.075 |

At short lead the model relies almost entirely on the present ionospheric state. At long lead
the ranking inverts and **solar geometry at the target hour becomes the single most important
feature**, followed by the TEC tendency. The model has recovered, from data alone, the fact
that the ionosphere is driven by solar illumination.

### 5.3 Where the advantage actually comes from

Aggregate RMSE hides an important nuance. Counting how often the model is closer than
persistence on each individual case gives a very different picture:

| Lead | Model wins | Median abs error, model | Median, persistence | RMSE, model | RMSE, persistence |
|---|---|---|---|---|---|
| 1 h | 51.9% | 1.74 | 1.70 | 4.00 | 4.88 |
| 2 h | 57.4% | 2.05 | 2.40 | 3.97 | 5.57 |
| 6 h | **81.1%** | **1.67** | 6.10 | 3.11 | 9.81 |

**At a one-hour lead the model is barely better than a coin toss case by case**, and its
*typical* error is marginally worse than persistence (1.74 against 1.70 TECU). Its lower RMSE
comes entirely from avoiding the large errors, not from being closer most of the time. That is
a meaningful distinction: at short lead the model is best understood as a variance-reducer
rather than a better point forecast.

At six hours the picture changes completely — it wins 81.1% of cases and its median error is
less than a third of persistence's.

Restricting to the 26–28 August storm (Kp ≥ 5, n = 164 per horizon):

| Lead | Model RMSE | Persistence RMSE | Model wins |
|---|---|---|---|
| 1 h | 6.93 | 8.26 | 40.9% |
| 2 h | 7.70 | 9.03 | 46.3% |
| 6 h | 4.43 | 14.92 | 70.7% |

Errors roughly double during the storm, and at short lead the model loses more often than it
wins — yet its RMSE stays below persistence at every horizon, for the same reason: it avoids
the worst misses. Storm-time ionospheric forecasting is genuinely hard, and these numbers
should not be smoothed over.

### 5.4 A negative result, reported

**Lightning features do not appear among the important predictors at any lead time.**
Lightning activity does not measurably drive TEC at these scales. The honest framing of this
project is therefore that it forecasts the propagation environment *over lightning-active
regions* — the lightning data defines where and when the forecast is made — rather than
forecasting that environment *from* lightning. This is reported rather than concealed.

## 6. Propagation quantities

With TEC in electrons·m⁻² and equivalent slab thickness τ = 300 km:

    NmF2 ≈ TEC / τ
    foF2 [Hz] = 8.98 · sqrt(NmF2 [m⁻³])
    MUF = foF2 / cos φ
    D = 2R · [ π/2 − θ_el − arcsin( R cos θ_el / (R + h) ) ]

Applied across the observed TEC range:

| TEC (TECU) | foF2 (MHz) | MUF at 5° (MHz) |
|---|---|---|
| 5 | 3.67 | 11.90 |
| 10 | 5.18 | 16.83 |
| 20 | 7.33 | 23.81 |
| 40 | 10.37 | 33.67 |
| 64 | 13.12 | 42.59 |

One-hop ground range at 5° take-off and 300 km reflection height: **2,877 km**.

> **Unit note.** The plasma-frequency coefficient 8.98 returns **hertz**. Writing it as
> `8.98e-3` for MHz overstates `foF2` by a factor of 1000 — real values are a few MHz, not a
> few thousand. This error was made and caught during development.

## 7. Case study — the 26 August 2018 geomagnetic storm

The test period contains a strong storm: Dst falls to **−176 nT** and Kp reaches **7.3**.
Mean equatorial TEC (|lat| ≤ 30°) first rises sharply to about 16.5 TECU — the *positive storm
phase*, in which storm-time electric fields lift plasma to greater heights — and then falls
below its pre-storm level in the *negative phase*, driven by changes in neutral composition.

This is textbook storm-time ionospheric behaviour, reproduced here directly from raw NASA
files, and it confirms that the processing chain preserves real geophysical signal.

## 8. Data-quality issues found and resolved

Processed data was verified against freshly downloaded source files rather than assumed
correct. Four defects were found and fixed:

1. **IONEX hour-24 convention.** The format writes end-of-day midnight as hour 24, which
   standard date parsers reject; every file initially failed to parse.
2. **A silent 1000× error in the time axis.** `pandas` 3.x `DatetimeIndex` can carry
   microsecond resolution, so `.astype("int64")` is not reliably nanoseconds; dividing by 1e9
   placed the entire six-month series in January 1970. Nothing crashed — every temporal join
   would have been silently wrong.
3. **Double application of `scale_factor`.** netCDF4 applies a variable's scale factor on
   *write* as well as on read, so pre-multiplying stored `TEC × 100` under a 0.1 factor and
   inflated every value tenfold.
4. **Day-boundary duplicate epochs.** Each daily file ends with a `24:00` map duplicating the
   next day's `00:00`, but the two differ by up to **22.2 TECU** because the former is
   extrapolated past its solution window. Deduplication now keeps the correctly-solved value.

After these fixes the stored cube reproduces freshly downloaded source files **exactly**
(0.0000 TECU) at every interior epoch, and the time series is gapless — 17,665 epochs, every
one of the 17,664 intervals exactly 15 minutes.

## 9. Limitations

1. **Slab thickness is assumed constant** at 300 km; in reality it varies with location,
   season and solar activity, so `foF2` and MUF inherit that systematic uncertainty.
2. **TEC is an F2-region quantity, whereas VLF waveguide propagation is governed by the D and
   E regions.** TEC is a proxy for the propagation environment, not a direct measure of VLF
   reflection height. This is the most important caveat in the project.
3. **Global ionosphere maps are themselves model products** interpolated from a finite GNSS
   network; the cube's minimum of −3.6 TECU is unphysical and an artefact of that inversion.
4. **LIS sampling is intermittent** and limited to ±55° latitude by the ISS orbit.
5. **One season of one year.** 2018 was deep solar minimum; solar-maximum conditions, with
   several times higher TEC, are untested.
6. **Lightning features contribute little**, as reported in §5.3.

## 10. Conclusions

1. A non-circular, physically meaningful machine-learning formulation of the project title was
   constructed entirely from NASA data.
2. All five models beat the persistence benchmark; gradient boosting reached **RMSE 3.11 TECU,
   R² 0.69 and skill +0.68** at a six-hour lead.
3. Forecast skill **increases** with lead time, because persistence decays over the diurnal
   cycle while solar geometry does not.
4. The model independently recovered solar illumination as the dominant physical driver at
   long lead times.
5. Forecast TEC was converted into `foF2`, MUF and one-hop ground range.
6. Lightning activity was found **not** to be a useful predictor of TEC, and this is reported
   as a genuine negative result.

## 11. Reproducing this work

    src/ionex.py              IONEX parser and interpolation
    src/download_tec.sh       bulk CDDIS download of UQRG maps
    src/build_tec_cube.py     IONEX text -> compressed netCDF cube
    src/build_flash_table.py  stream LIS granules -> flash tables
    src/build_omni.py         OMNI2 -> driver table
    src/features.py           solar geometry, magnetic latitude, foF2 / MUF / hop range
    src/build_dataset.py      join everything into the supervised table
    src/train.py              model comparison
    src/fit_best.py           refit best model, save predictions
    src/figures.py            all report figures
    src/make_notebook.py      build the notebook

## References

1. NASA GHRC DAAC — *Quality Controlled Lightning Imaging Sensor (LIS) on International Space
   Station (ISS) Science Data V3* (`isslis_v3_fin`).
2. NASA CDDIS — UPC-IonSAT UQRG rapid global ionosphere maps (IONEX format).
3. NASA SPDF — OMNI2 hourly solar wind and geomagnetic index dataset.
4. *Lightning Mapping: Techniques, Challenges, and Opportunities*, arXiv:2006.00563.
5. Davies, K., *Ionospheric Radio*, Peter Peregrinus, 1990.
6. Schaer, S., Gurtner, W., Feltens, J., *IONEX: The IONosphere Map EXchange Format Version 1*,
   Proceedings of the IGS Analysis Center Workshop, 1998.
