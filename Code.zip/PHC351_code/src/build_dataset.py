"""Join lightning, ionosphere and space-weather data into the supervised learning table.

One sample = one (TEC grid cell, 15-minute epoch) in which LIS observed lightning.
Aggregating to the grid avoids feeding the model thousands of near-identical rows for a
single storm, which would leak between train and test.

Target: vertical TEC in that cell at t + horizon. Known-in-advance astronomical terms
(solar zenith angle at the target time) are legitimate features; nothing derived from the
target epoch's TEC is used as an input.
"""
import sys, numpy as np, pandas as pd, netCDF4 as nc
sys.path.insert(0, "src")
import features as F

HORIZONS = {"1h": 4, "2h": 8, "6h": 24}      # in 15-minute steps
LAGS = {"lag_15m": 1, "lag_30m": 2, "lag_1h": 4, "lag_2h": 8, "lag_3h": 12}


def main():
    d = nc.Dataset("data/processed/tec_cube.nc")
    times = pd.to_datetime(d["time"][:], unit="s")
    lats = np.asarray(d["lat"][:]); lons = np.asarray(d["lon"][:])
    tec = np.ma.filled(d["tec"][:], np.nan).astype("float32")
    print(f"TEC cube {tec.shape}  {times[0]} -> {times[-1]}", flush=True)

    fl = pd.read_parquet("data/interim/flashes_all.parquet")
    fl["utc"] = pd.to_datetime(fl.tai93, unit="s", origin="1993-01-01")
    fl = fl[(fl.utc >= times[0]) & (fl.utc <= times[-1])].copy()
    print(f"flashes in cube window: {len(fl):,}", flush=True)

    # --- bin each flash to the nearest TEC cell and 15-minute epoch ---
    fl["iy"] = np.abs(fl.lat.values[:, None] - lats[None, :]).argmin(1)
    fl["ix"] = np.abs(((fl.lon.values + 180) % 360 - 180)[:, None] - lons[None, :]).argmin(1)
    t0 = times[0].value // 10**9
    secs = fl.utc.values.astype("datetime64[s]").astype("int64") - t0
    fl["it"] = np.clip(np.round(secs / 900).astype(int), 0, len(times) - 1)

    # --- aggregate flash activity per cell-epoch ---
    g = fl.groupby(["it", "iy", "ix"])
    X = g.agg(
        n_flashes=("radiance", "size"),
        rad_mean=("radiance", "mean"),
        rad_max=("radiance", "max"),
        rad_sum=("radiance", "sum"),
        fp_mean=("footprint", "mean"),
        fp_sum=("footprint", "sum"),
        dur_mean=("duration_s", "mean"),
        ngroups_mean=("n_groups", "mean"),
        nevents_sum=("n_events", "sum"),
        oblong_mean=("oblong", "mean"),
    ).reset_index()
    print(f"cell-epoch samples: {len(X):,}", flush=True)

    for c in ("rad_mean", "rad_max", "rad_sum", "fp_sum", "nevents_sum"):
        X["log_" + c] = np.log10(np.clip(X[c].values, 1, None))

    it, iy, ix = X.it.values, X.iy.values, X.ix.values
    X["lat"] = lats[iy]; X["lon"] = lons[ix]
    X["time"] = times[it]

    # --- TEC history (all strictly at or before t) ---
    X["tec_now"] = tec[it, iy, ix]
    for name, lag in LAGS.items():
        ok = it - lag >= 0
        v = np.full(len(X), np.nan, "float32")
        v[ok] = tec[it[ok] - lag, iy[ok], ix[ok]]
        X["tec_" + name] = v
        X["dtec_" + name] = X.tec_now - X["tec_" + name]

    # spatial context: mean TEC of the 8 neighbouring cells at time t
    ny, nx = len(lats), len(lons)
    nb = []
    for dy in (-1, 0, 1):
        for dx in (-1, 0, 1):
            if dy == 0 and dx == 0:
                continue
            nb.append(tec[it, np.clip(iy + dy, 0, ny - 1), (ix + dx) % nx])
    X["tec_neigh_mean"] = np.nanmean(np.vstack(nb), axis=0)
    X["tec_neigh_grad"] = X.tec_now - X.tec_neigh_mean

    # --- geometry ---
    tv = X.time.values
    X["maglat"] = F.magnetic_latitude(X.lat.values, X.lon.values)
    X["cos_sza"] = F.solar_zenith_cos(tv, X.lat.values, X.lon.values)
    doy = pd.DatetimeIndex(X.time).dayofyear.values
    X["doy_sin"] = np.sin(2 * np.pi * doy / 365.25)
    X["doy_cos"] = np.cos(2 * np.pi * doy / 365.25)
    lt = (pd.DatetimeIndex(X.time).hour.values + pd.DatetimeIndex(X.time).minute.values / 60
          + X.lon.values / 15.0) % 24
    X["lt_sin"] = np.sin(2 * np.pi * lt / 24)
    X["lt_cos"] = np.cos(2 * np.pi * lt / 24)
    X["abs_lat"] = X.lat.abs()
    X["abs_maglat"] = X.maglat.abs()

    # --- space weather drivers at the nearest hour <= t ---
    omni = pd.read_parquet("data/processed/omni_drivers.parquet")
    X = pd.merge_asof(X.sort_values("time"), omni.reset_index().sort_values("time"),
                      on="time", direction="backward")

    # --- targets, plus the solar geometry of the target epoch (known in advance) ---
    for name, h in HORIZONS.items():
        ok = it + h < len(times)
        y = np.full(len(X), np.nan, "float32")
        y[ok] = tec[it[ok] + h, iy[ok], ix[ok]]
        X[f"y_tec_{name}"] = y
        X[f"cos_sza_{name}"] = F.solar_zenith_cos(
            tv + np.timedelta64(h * 15, "m"), X.lat.values, X.lon.values)

    X.to_parquet("data/processed/dataset.parquet", compression="zstd", index=False)
    print(f"\nwrote data/processed/dataset.parquet  rows={len(X):,} cols={X.shape[1]}", flush=True)
    print("date range:", X.time.min(), "->", X.time.max())
    print("\ntarget availability:")
    for name in HORIZONS:
        print(f"  y_tec_{name}: {X[f'y_tec_{name}'].notna().sum():,} non-null")


if __name__ == "__main__":
    main()
