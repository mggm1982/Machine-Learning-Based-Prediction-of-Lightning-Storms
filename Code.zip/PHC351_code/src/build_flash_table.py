"""Stream ISS-LIS granules: download a day, extract the flash table, delete the raw files.

Keeps peak disk use to one day of granules (~90 MB) instead of the full ~5.6 GB archive.
"""
import argparse, datetime as dt, os, sys, warnings
from pathlib import Path
import numpy as np, pandas as pd, netCDF4 as nc, earthaccess

warnings.filterwarnings("ignore")

FLASH_VARS = {
    "TAI93_time": "tai93", "lat": "lat", "lon": "lon",
    "radiance": "radiance", "footprint": "footprint",
    "delta_time": "duration_s", "observe_time": "observe_s",
    "child_count": "n_groups", "grandchild_count": "n_events",
    "oblong_index": "oblong", "cluster_index": "cluster_idx",
    "density_index": "density_idx", "noise_index": "noise_idx",
    "glint_index": "glint_idx", "approx_threshold": "approx_thresh",
    "alert_flag": "alert_flag",
}


def extract(path):
    """Flash-level records from one granule, or None if it holds no flashes."""
    try:
        with nc.Dataset(path) as d:
            if "lightning_flash_lat" not in d.variables:
                return None
            n = d.dimensions["flash_dim"].size
            if n == 0:
                return None
            cols = {}
            for src, dst in FLASH_VARS.items():
                v = d.variables.get(f"lightning_flash_{src}")
                cols[dst] = np.asarray(v[:]).astype("float64") if v is not None else np.nan
            df = pd.DataFrame(cols)
            df["granule"] = Path(path).name
            return df
    except Exception as e:
        print(f"    EXTRACT_FAIL {Path(path).name}: {e}", flush=True)
        return None


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--start", default="2018-03-01")
    p.add_argument("--end", default="2018-08-31")
    p.add_argument("--every", type=int, default=3)
    p.add_argument("--tmp", default="data/raw/lis")
    p.add_argument("--out", default="data/interim/flashes")
    a = p.parse_args()

    earthaccess.login(strategy="netrc")
    tmp, out = Path(a.tmp), Path(a.out)
    tmp.mkdir(parents=True, exist_ok=True); out.mkdir(parents=True, exist_ok=True)

    d0, d1 = dt.date.fromisoformat(a.start), dt.date.fromisoformat(a.end)
    days = [d0 + dt.timedelta(days=i) for i in range(0, (d1 - d0).days + 1, a.every)]
    print(f"{len(days)} days", flush=True)

    for i, day in enumerate(days, 1):
        dest = out / f"flashes_{day.isoformat()}.parquet"
        if dest.exists():
            print(f"[{i}/{len(days)}] {day} SKIP (done)", flush=True); continue
        try:
            res = earthaccess.search_data(
                short_name="isslis_v3_fin",
                temporal=(day.isoformat(), (day + dt.timedelta(days=1)).isoformat()))
            granules = [g for g in res if g["umm"]["GranuleUR"].endswith(".nc")]
            have = {f.name for f in tmp.glob("*.nc")}
            todo = [g for g in granules if g["umm"]["GranuleUR"] not in have]
            if todo:
                earthaccess.download(todo, str(tmp))
        except Exception as e:
            print(f"[{i}/{len(days)}] {day} FAIL {e}", flush=True); continue

        frames = []
        for g in granules:
            f = tmp / g["umm"]["GranuleUR"]
            if f.exists():
                df = extract(f)
                if df is not None:
                    frames.append(df)
        if frames:
            day_df = pd.concat(frames, ignore_index=True)
            day_df.to_parquet(dest, compression="zstd", index=False)
            print(f"[{i}/{len(days)}] {day}: {len(granules)} granules -> "
                  f"{len(day_df):,} flashes", flush=True)
        else:
            pd.DataFrame().to_parquet(dest)
            print(f"[{i}/{len(days)}] {day}: no flashes", flush=True)

        for f in tmp.glob("*.nc"):   # free the disk before the next day
            f.unlink()

    print("DONE", flush=True)


if __name__ == "__main__":
    main()
