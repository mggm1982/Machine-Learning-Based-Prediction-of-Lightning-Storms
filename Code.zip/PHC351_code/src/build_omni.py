"""Parse NASA OMNI2 hourly records into the solar/geomagnetic drivers used as features.

OMNI2 is a fixed 55-word hourly format; only the indices below are used here.
Each field has its own documented fill value, which must be mapped to NaN per column
rather than with one global sentinel.
"""
import numpy as np, pandas as pd

# 1-based word numbers from the OMNI2 format description -> (name, fill value)
COLS = {
    39: ("kp10",    99),        # Kp in units of 10 (33 -> Kp 3.3)
    40: ("sunspot", 999),
    41: ("dst",     99999),
    42: ("ae",      9999),
    50: ("ap",      999),
    51: ("f107",    999.9),
}


def load(path="data/raw/omni2_2018.dat"):
    rows = [l.split() for l in open(path)]
    arr = np.array(rows, dtype="float64")

    year = arr[:, 0].astype(int)
    doy = arr[:, 1].astype(int)
    hour = arr[:, 2].astype(int)
    t = (pd.to_datetime(year.astype(str) + doy.astype(str).str.zfill(3)
                        if False else
                        [f"{y}-{d:03d}" for y, d in zip(year, doy)], format="%Y-%j")
         + pd.to_timedelta(hour, unit="h"))

    out = pd.DataFrame({"time": t})
    for word, (name, fill) in COLS.items():
        v = arr[:, word - 1].copy()
        v[v >= fill] = np.nan
        out[name] = v
    out["kp"] = out.pop("kp10") / 10.0

    out = out.set_index("time").sort_index()
    # F10.7 and sunspot number are daily values repeated hourly; Kp is 3-hourly.
    # Short gaps are interpolated; anything longer is left as NaN and dropped downstream.
    out = out.interpolate(limit=6, limit_direction="both")
    return out


if __name__ == "__main__":
    df = load()
    print(df.describe().round(2).to_string())
    print("\nrows:", len(df), "| range:", df.index[0], "->", df.index[-1])
    print("NaNs per column:\n", df.isna().sum().to_string())
    df.to_parquet("data/processed/omni_drivers.parquet")
    print("\nwrote data/processed/omni_drivers.parquet")
