"""Convert a directory of IONEX files into one compressed netCDF TEC cube, then free the text."""
import sys, glob, os
import numpy as np, netCDF4 as nc, pandas as pd
sys.path.insert(0, "src")
from ionex import read_ionex

files = sorted(glob.glob("data/raw/tec/uqrg*"))
print(f"{len(files)} IONEX files", flush=True)

times_all, grids = [], []
lats = lons = None
for n, f in enumerate(files, 1):
    try:
        t, la, lo, tec = read_ionex(f)
    except Exception as e:
        print(f"  SKIP {os.path.basename(f)}: {e}", flush=True); continue
    if len(t) != 97:          # UQRG is 15-min: 96 intervals + the 24:00 endpoint
        print(f"  WARN {os.path.basename(f)}: {len(t)} maps, expected 97 "
              f"(possible truncated download)", flush=True)
    if lats is None:
        lats, lons = la, lo
    times_all.append(t); grids.append(tec.astype(np.float32))
    if n % 40 == 0:
        print(f"  {n}/{len(files)}", flush=True)

times = pd.DatetimeIndex(np.concatenate([t.values for t in times_all]))
cube = np.concatenate(grids, axis=0)
order = np.argsort(times.values, kind="stable")   # stable: day N stays before day N+1
times, cube = times[order], cube[order]
# Each day's file repeats the next day's 00:00 as its own 24:00 map, but that last map is
# extrapolated past the daily solution window and can differ by >20 TECU from the next
# day's properly-solved 00:00. Keep the LAST occurrence, i.e. each epoch comes from the
# file whose own day it belongs to.
keep = np.concatenate([np.diff(times.values) != np.timedelta64(0, "ns"), [True]])
times, cube = times[keep], cube[keep]
print(f"cube: {cube.shape}  {times[0]} -> {times[-1]}", flush=True)

out = "data/processed/tec_cube.nc"
os.makedirs("data/processed", exist_ok=True)
with nc.Dataset(out, "w") as d:
    d.createDimension("time", len(times))
    d.createDimension("lat", len(lats))
    d.createDimension("lon", len(lons))
    vt = d.createVariable("time", "f8", ("time",))
    vt.units = "seconds since 1970-01-01"
    # pandas >=3 DatetimeIndex may be microsecond-resolution, so .astype("int64")
    # is NOT always nanoseconds; convert through an explicit second-resolution dtype
    vt[:] = (times.values.astype("datetime64[s]")
             - np.datetime64("1970-01-01T00:00:00", "s")).astype("int64")
    d.createVariable("lat", "f4", ("lat",))[:] = lats
    d.createVariable("lon", "f4", ("lon",))[:] = lons
    # store as int16 in 0.1 TECU (IONEX native precision) + zlib: ~6x smaller than text
    v = d.createVariable("tec", "i2", ("time", "lat", "lon"),
                         zlib=True, complevel=4, fill_value=-9999)
    v.scale_factor, v.units, v.long_name = 0.01, "TECU", "Vertical total electron content"
    # netCDF4 applies scale_factor automatically on WRITE as well as on read, so hand it
    # physical TECU values -- scaling them here too would store TEC*100 under a 0.1 factor.
    v[:] = np.ma.masked_invalid(cube)
    d.source = "UPC-IonSAT UQRG rapid 15-min GIM via NASA CDDIS"
print("wrote", out, os.path.getsize(out) / 1e6, "MB", flush=True)
