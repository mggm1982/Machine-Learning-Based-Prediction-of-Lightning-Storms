"""Download ISS-LIS V3 quality-controlled science granules (netCDF only) from NASA GHRC."""
import argparse, datetime as dt, sys
from pathlib import Path
import earthaccess


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--start", default="2018-03-01")
    p.add_argument("--end", default="2018-08-31")
    p.add_argument("--every", type=int, default=3, help="sample every Nth day")
    p.add_argument("--out", default="data/raw/lis")
    a = p.parse_args()

    earthaccess.login(strategy="netrc")
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)

    d0 = dt.date.fromisoformat(a.start)
    d1 = dt.date.fromisoformat(a.end)
    days = [d0 + dt.timedelta(days=i) for i in range(0, (d1 - d0).days + 1, a.every)]
    print(f"{len(days)} days to fetch", flush=True)

    total = 0
    for i, day in enumerate(days, 1):
        nxt = day + dt.timedelta(days=1)
        try:
            res = earthaccess.search_data(
                short_name="isslis_v3_fin",
                temporal=(day.isoformat(), nxt.isoformat()),
            )
        except Exception as e:
            print(f"[{i}/{len(days)}] {day} SEARCH_FAIL {e}", flush=True); continue

        # keep netCDF only; the archive also carries an .hdf twin of every granule
        nc = [g for g in res if g["umm"]["GranuleUR"].endswith(".nc")]
        todo = [g for g in nc if not (out / g["umm"]["GranuleUR"]).exists()]
        if todo:
            try:
                earthaccess.download(todo, str(out))
            except Exception as e:
                print(f"[{i}/{len(days)}] {day} DL_FAIL {e}", flush=True); continue
        total += len(nc)
        print(f"[{i}/{len(days)}] {day}: {len(nc)} granules ({len(todo)} new)", flush=True)

    print(f"TOTAL granules on disk: {len(list(out.glob('*.nc')))}", flush=True)


if __name__ == "__main__":
    main()
