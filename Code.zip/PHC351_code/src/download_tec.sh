#!/bin/bash
# Download UPC-IonSAT UQRG 15-minute global ionosphere maps (TEC) from NASA CDDIS.
# Usage: ./download_tec.sh <year> <doy_start> <doy_end> <outdir>
YEAR=$1; D0=$2; D1=$3; OUT=$4
mkdir -p "$OUT"
COOKIES=$(mktemp)
fetch() {
  local doy=$(printf "%03d" $1)
  local f="uqrg${doy}0.${YEAR:2:2}i"
  [ -s "$OUT/$f" ] && { echo "SKIP $f"; return; }
  curl -s -L -n -c "$COOKIES" -b "$COOKIES" --max-time 300 --retry 3 \
       "https://cddis.nasa.gov/archive/gnss/products/ionex/${YEAR}/${doy}/${f}.Z" \
       -o "$OUT/${f}.Z" -w "%{http_code}" > "$OUT/.status_$doy"
  if [ "$(cat "$OUT/.status_$doy")" = "200" ] && [ -s "$OUT/${f}.Z" ]; then
     gzip -dc "$OUT/${f}.Z" > "$OUT/$f" 2>/dev/null && rm -f "$OUT/${f}.Z" && echo "OK   $f" || echo "GUNZIP_FAIL $f"
  else
     echo "FAIL $f ($(cat "$OUT/.status_$doy"))"; rm -f "$OUT/${f}.Z"
  fi
  rm -f "$OUT/.status_$doy"
}
export -f fetch; export YEAR OUT COOKIES
seq $D0 $D1 | xargs -P 6 -I{} bash -c 'fetch {}'
rm -f "$COOKIES"
echo "DONE: $(ls -1 $OUT/uqrg* 2>/dev/null | wc -l) files"
