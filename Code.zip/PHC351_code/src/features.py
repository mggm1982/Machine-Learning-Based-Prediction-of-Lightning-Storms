"""Geophysical helper functions: solar geometry and geomagnetic coordinates."""
import numpy as np

# IGRF dipole north geomagnetic pole, epoch ~2018
POLE_LAT, POLE_LON = 80.65, -72.68


def solar_zenith_cos(when, lat, lon):
    """cos(solar zenith angle). Positive = Sun above horizon.

    NOAA low-precision solar position: adequate here, since this feeds a feature
    rather than an ephemeris.
    """
    when = np.asarray(when, dtype="datetime64[s]")
    lat = np.asarray(lat, float); lon = np.asarray(lon, float)

    day = when.astype("datetime64[D]")
    doy = (day - day.astype("datetime64[Y]")).astype(int) + 1
    sec = (when - day).astype("float64")
    frac_hour = sec / 3600.0

    g = np.radians((360 / 365.25) * (doy - 81))                 # orbital angle
    decl = np.radians(23.44) * np.sin(g)                        # solar declination
    eot = 9.87 * np.sin(2 * g) - 7.53 * np.cos(g) - 1.5 * np.sin(g)   # minutes

    solar_time = frac_hour + lon / 15.0 + eot / 60.0
    hour_angle = np.radians(15.0 * (solar_time - 12.0))

    la = np.radians(lat)
    return (np.sin(la) * np.sin(decl)
            + np.cos(la) * np.cos(decl) * np.cos(hour_angle))


def magnetic_latitude(lat, lon):
    """Geomagnetic latitude under a centred-dipole approximation (degrees)."""
    la, lo = np.radians(np.asarray(lat, float)), np.radians(np.asarray(lon, float))
    pla, plo = np.radians(POLE_LAT), np.radians(POLE_LON)
    s = (np.sin(la) * np.sin(pla)
         + np.cos(la) * np.cos(pla) * np.cos(lo - plo))
    return np.degrees(np.arcsin(np.clip(s, -1, 1)))


def tec_to_fof2(tec_tecu, slab_km=300.0):
    """foF2 in MHz from vertical TEC, via an equivalent slab thickness.

    NmF2 = TEC / tau ;  fp[Hz] = 8.98 * sqrt(NmF2 [m^-3])

    The classical plasma-frequency coefficient 8.98 returns Hz, so the MHz form
    carries 8.98e-6. Using 8.98e-3 overstates foF2 by a factor of 1000.
    """
    tec = np.clip(np.asarray(tec_tecu, float), 0, None) * 1e16    # TECU -> electrons/m^2
    nmf2 = tec / (slab_km * 1e3)                                  # electrons/m^3
    return 8.98e-6 * np.sqrt(nmf2)


def muf(fof2_mhz, elevation_deg=5.0, h_km=300.0, R_km=6371.0):
    """Maximum usable frequency (MHz) for a one-hop path at a given take-off elevation."""
    el = np.radians(elevation_deg)
    # angle of incidence at the reflecting layer
    sin_phi = R_km * np.cos(el) / (R_km + h_km)
    cos_phi = np.sqrt(np.clip(1 - sin_phi ** 2, 0, 1))
    return np.asarray(fof2_mhz, float) / np.clip(cos_phi, 1e-6, None)


def hop_range_km(elevation_deg=5.0, h_km=300.0, R_km=6371.0):
    """One-hop ground range (km) for a given take-off elevation and reflection height."""
    el = np.radians(elevation_deg)
    sin_phi = R_km * np.cos(el) / (R_km + h_km)
    phi = np.arcsin(np.clip(sin_phi, -1, 1))
    half_central = np.pi / 2 - el - phi
    return 2 * R_km * half_central
