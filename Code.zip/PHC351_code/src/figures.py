"""Generate all report figures."""
import os, certifi
# the python.org interpreter ships no CA bundle, so cartopy's Natural Earth
# downloads fail SSL verification unless pointed at certifi's
os.environ.setdefault("SSL_CERT_FILE", certifi.where())

import sys, json, warnings
import numpy as np, pandas as pd, netCDF4 as nc
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
import cartopy.crs as ccrs
import cartopy.feature as cfeature
sys.path.insert(0, "src")
import features as F

warnings.filterwarnings("ignore")
FIG = "reports/figures"

# validated categorical slots (dataviz reference palette, light mode)
C = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300"]
INK, INK2, GRID = "#0b0b0b", "#52514e", "#d8d7d2"

plt.rcParams.update({
    "figure.dpi": 140, "savefig.dpi": 160, "savefig.bbox": "tight",
    "font.size": 9, "axes.titlesize": 11, "axes.titleweight": "600",
    "axes.labelcolor": INK2, "text.color": INK,
    "axes.edgecolor": GRID, "axes.linewidth": 0.8,
    "xtick.color": INK2, "ytick.color": INK2,
    "grid.color": GRID, "grid.linewidth": 0.6,
    "figure.facecolor": "white", "axes.facecolor": "white",
    "legend.frameon": False,
})


def basemap(ax, extent=(-180, 180, -60, 60)):
    ax.set_extent(extent, crs=ccrs.PlateCarree())
    ax.add_feature(cfeature.COASTLINE.with_scale("110m"), linewidth=0.4, edgecolor="#9a9a93")
    ax.add_feature(cfeature.BORDERS.with_scale("110m"), linewidth=0.2, edgecolor="#cfcec9")
    gl = ax.gridlines(draw_labels=True, linewidth=0.4, color=GRID, alpha=0.7)
    gl.top_labels = gl.right_labels = False
    gl.xlabel_style = gl.ylabel_style = {"size": 7, "color": INK2}


# ---------------------------------------------------------------- fig 1
def fig_coverage(fl):
    fig = plt.figure(figsize=(10, 4.6))
    ax = plt.axes(projection=ccrs.PlateCarree())
    basemap(ax)
    h = ax.hexbin(fl.lon, fl.lat, gridsize=(110, 44), mincnt=1, bins="log",
                  cmap="Blues", transform=ccrs.PlateCarree(), linewidths=0)
    cb = fig.colorbar(h, ax=ax, orientation="vertical", pad=0.02, shrink=0.8)
    cb.set_label("flashes per cell (log scale)", color=INK2, size=8)
    cb.ax.tick_params(labelsize=7, color=GRID)
    ax.set_title("NASA ISS-LIS lightning flashes, March–August 2018\n"
                 f"{len(fl):,} flashes · ISS orbit limits coverage to ±55° latitude",
                 loc="left", color=INK)
    fig.savefig(f"{FIG}/fig01_lightning_coverage.png"); plt.close(fig)
    print("fig01 done")


# ---------------------------------------------------------------- fig 2
def fig_tec_snapshot(times, lats, lons, tec, fl):
    when = pd.Timestamp("2018-08-26 18:00")          # peak of the Aug 2018 storm
    i = int(np.argmin(np.abs(times - when)))
    fig = plt.figure(figsize=(10, 4.6))
    ax = plt.axes(projection=ccrs.PlateCarree())
    basemap(ax, extent=(-180, 180, -87, 87))
    m = ax.pcolormesh(lons, lats, tec[i], cmap="Blues", shading="auto",
                      transform=ccrs.PlateCarree(), vmin=0)
    w = fl[(fl.utc >= times[i] - pd.Timedelta("30min")) & (fl.utc <= times[i] + pd.Timedelta("30min"))]
    ax.scatter(w.lon, w.lat, s=3, c=C[1], alpha=0.8, transform=ccrs.PlateCarree(),
               label=f"LIS flashes ±30 min (n={len(w):,})", linewidths=0)
    cb = fig.colorbar(m, ax=ax, pad=0.02, shrink=0.8); cb.set_label("vertical TEC (TECU)", color=INK2, size=8)
    cb.ax.tick_params(labelsize=7)
    ax.legend(loc="lower left", fontsize=8, markerscale=2.5)
    ax.set_title(f"Ionospheric TEC and lightning · {times[i]:%Y-%m-%d %H:%M} UTC\n"
                 "the equatorial ionisation anomaly is the dominant structure",
                 loc="left", color=INK)
    fig.savefig(f"{FIG}/fig02_tec_and_lightning.png"); plt.close(fig)
    print("fig02 done")


# ---------------------------------------------------------------- fig 3
def fig_models(res):
    piv = res.pivot(index="model", columns="horizon", values="rmse")
    order = ["Persistence", "Ridge", "MLP", "RandomForest", "XGBoost", "HistGradBoost"]
    piv = piv.loc[[m for m in order if m in piv.index]]
    hs = ["1h", "2h", "6h"]
    fig, ax = plt.subplots(figsize=(8.6, 4.4))
    x = np.arange(len(piv)); w = 0.26
    for k, h in enumerate(hs):
        off = (k - 1) * (w + 0.02)
        b = ax.bar(x + off, piv[h], w, color=C[k], label=f"{h} ahead",
                   edgecolor="white", linewidth=1.4)
        ax.bar_label(b, fmt="%.2f", fontsize=6.6, padding=2, color=INK2)
    ax.axhline(0, color=GRID, lw=0.8)
    ax.set_xticks(x); ax.set_xticklabels(piv.index, fontsize=8.5)
    ax.set_ylabel("test RMSE (TECU) — lower is better")
    ax.grid(axis="y", alpha=0.5); ax.set_axisbelow(True)
    for s in ("top", "right"): ax.spines[s].set_visible(False)
    ax.legend(ncol=3, loc="upper right", fontsize=8)
    ax.set_title("Forecast error by model and lead time\n"
                 "every model beats persistence; the gap widens with lead time",
                 loc="left", color=INK)
    fig.savefig(f"{FIG}/fig03_model_comparison.png"); plt.close(fig)
    print("fig03 done")


# ---------------------------------------------------------------- fig 4
def fig_skill(res):
    d = res[res.model != "Persistence"]
    piv = d.pivot(index="horizon", columns="model", values="skill").loc[["1h", "2h", "6h"]]
    fig, ax = plt.subplots(figsize=(8.2, 4.2))
    for k, m in enumerate(piv.columns):
        ax.plot(piv.index, piv[m], marker="o", ms=7, lw=2, color=C[k % len(C)], label=m)
        ax.annotate(f"{piv[m].iloc[-1]:+.2f}", (2, piv[m].iloc[-1]), xytext=(8, 0),
                    textcoords="offset points", fontsize=8, color=INK2, va="center")
    ax.axhline(0, color=INK2, lw=1, ls="--")
    ax.text(0.02, 0.02, "0 = no better than persistence", transform=ax.transAxes,
            fontsize=7.5, color=INK2)
    ax.set_ylabel("skill score vs persistence"); ax.set_xlabel("forecast lead time")
    ax.grid(axis="y", alpha=0.5); ax.set_axisbelow(True)
    for s in ("top", "right"): ax.spines[s].set_visible(False)
    ax.legend(ncol=3, fontsize=8, loc="upper left")
    ax.set_xlim(-0.3, 2.45)
    ax.set_title("Skill over persistence grows with lead time\n"
                 "persistence decays over a quarter of the diurnal cycle; the models do not",
                 loc="left", color=INK)
    fig.savefig(f"{FIG}/fig04_skill_scores.png"); plt.close(fig)
    print("fig04 done")


# ---------------------------------------------------------------- fig 5
def fig_importance(imp):
    # NOT sharex: the 1h panel's top feature is ~3x the 6h panel's, and a shared
    # x-limit would push that bar and its label off the axes
    fig, axes = plt.subplots(1, 2, figsize=(10, 4.6))
    for ax, h, col in zip(axes, ("1h", "6h"), (C[0], C[2])):
        top = list(imp[h].items())[:11][::-1]
        names = [k for k, _ in top]; vals = [v for _, v in top]
        b = ax.barh(names, vals, color=col, height=0.68)
        ax.bar_label(b, fmt="%.3f", fontsize=6.6, padding=2, color=INK2)
        ax.set_title(f"{h} lead time", loc="left", color=INK, fontsize=10)
        ax.grid(axis="x", alpha=0.5); ax.set_axisbelow(True)
        ax.tick_params(labelsize=7.5)
        for s in ("top", "right", "left"): ax.spines[s].set_visible(False)
        ax.set_xlim(0, max(vals) * 1.22)
    axes[0].set_xlabel("XGBoost gain importance"); axes[1].set_xlabel("XGBoost gain importance")
    fig.suptitle("What the model relies on changes with lead time\n"
                 "short lead: current TEC state  ·  long lead: solar geometry at the target hour",
                 x=0.012, y=0.985, ha="left", va="top", color=INK, fontsize=11, fontweight="600")
    fig.tight_layout(rect=[0, 0, 1, 0.88])
    fig.savefig(f"{FIG}/fig05_feature_importance.png"); plt.close(fig)
    print("fig05 done")


# ---------------------------------------------------------------- fig 6
def fig_scatter(pred):
    hs = ["1h", "2h", "6h"]
    fig, axes = plt.subplots(1, 3, figsize=(11, 3.9), sharex=True, sharey=True)
    for ax, h in zip(axes, hs):
        d = pred[pred.horizon == h]
        lim = (0, max(d.y_true.max(), d.y_pred.max()) * 1.02)
        ax.hexbin(d.y_true, d.y_pred, gridsize=46, cmap="Blues", bins="log",
                  extent=(*lim, *lim), linewidths=0)
        ax.plot(lim, lim, color=INK2, lw=1, ls="--")
        r2 = 1 - ((d.y_true - d.y_pred) ** 2).sum() / ((d.y_true - d.y_true.mean()) ** 2).sum()
        rmse = np.sqrt(((d.y_true - d.y_pred) ** 2).mean())
        ax.set_title(f"{h} ahead   R²={r2:.3f}  RMSE={rmse:.2f}", loc="left",
                     fontsize=9.5, color=INK)
        ax.set_xlabel("observed TEC (TECU)")
        ax.set_xlim(lim); ax.set_ylim(lim); ax.grid(alpha=0.4); ax.set_axisbelow(True)
        for s in ("top", "right"): ax.spines[s].set_visible(False)
    axes[0].set_ylabel("predicted TEC (TECU)")
    fig.suptitle("Predicted vs observed TEC on the held-out test period (dashed = perfect)",
                 x=0.012, ha="left", color=INK, fontsize=11, fontweight="600")
    fig.tight_layout(rect=[0, 0, 1, 0.93])
    fig.savefig(f"{FIG}/fig06_pred_vs_obs.png"); plt.close(fig)
    print("fig06 done")


# ---------------------------------------------------------------- fig 7
def fig_physics(pred):
    d = pred[pred.horizon == "6h"]
    fig, axes = plt.subplots(1, 2, figsize=(10.6, 4.3))
    ax = axes[0]
    ax.hexbin(d.true_fof2, d.pred_fof2, gridsize=44, cmap="Blues", bins="log", linewidths=0)
    lim = (0, max(d.true_fof2.max(), d.pred_fof2.max()) * 1.02)
    ax.plot(lim, lim, color=INK2, lw=1, ls="--")
    ax.set_xlabel("observed foF2 (MHz)"); ax.set_ylabel("predicted foF2 (MHz)")
    ax.set_title("Critical frequency foF2", loc="left", color=INK, fontsize=10)
    ax.set_xlim(lim); ax.set_ylim(lim)

    ax = axes[1]
    ax.hexbin(d.true_muf, d.pred_muf, gridsize=44, cmap="Blues", bins="log", linewidths=0)
    lim = (0, max(d.true_muf.max(), d.pred_muf.max()) * 1.02)
    ax.plot(lim, lim, color=INK2, lw=1, ls="--")
    ax.set_xlabel("observed MUF (MHz)"); ax.set_ylabel("predicted MUF (MHz)")
    ax.set_title("Maximum usable frequency, 5° take-off", loc="left", color=INK, fontsize=10)
    ax.set_xlim(lim); ax.set_ylim(lim)
    for a in axes:
        a.grid(alpha=0.4); a.set_axisbelow(True)
        for s in ("top", "right"): a.spines[s].set_visible(False)
    err = np.sqrt(((d.true_muf - d.pred_muf) ** 2).mean())
    fig.suptitle("Propagation quantities derived from the 6-hour TEC forecast\n"
                 f"MUF RMSE = {err:.2f} MHz · one-hop ground range "
                 f"{F.hop_range_km():.0f} km at 5° elevation, 300 km reflection height",
                 x=0.012, ha="left", color=INK, fontsize=11, fontweight="600")
    fig.tight_layout(rect=[0, 0, 1, 0.9])
    fig.savefig(f"{FIG}/fig07_propagation_quantities.png"); plt.close(fig)
    print("fig07 done")


# ---------------------------------------------------------------- fig 8
def fig_storm(times, lats, lons, tec, omni):
    t0, t1 = pd.Timestamp("2018-08-23"), pd.Timestamp("2018-08-31")
    m = (times >= t0) & (times <= t1)
    eq = np.abs(lats) <= 30
    series = np.nanmean(tec[np.where(m)[0]][:, eq, :], axis=(1, 2))
    o = omni[(omni.index >= t0) & (omni.index <= t1)]

    # three stacked panels, one y-scale each: a twin axis for Kp would be a dual-axis chart
    fig, axes = plt.subplots(3, 1, figsize=(9.6, 6.4), sharex=True,
                             gridspec_kw={"height_ratios": [1.3, 1, 0.8]})
    axes[0].plot(times[m], series, color=C[0], lw=1.8)
    axes[0].set_ylabel("mean TEC (TECU)\n|lat| ≤ 30°")
    axes[0].set_title("The 26 August 2018 geomagnetic storm\n"
                      "equatorial TEC responds as Dst falls to −176 nT",
                      loc="left", color=INK)

    axes[1].plot(o.index, o.dst, color=C[1], lw=1.8)
    axes[1].axhline(-50, color=INK2, ls="--", lw=0.9)
    axes[1].text(t0, -44, "storm threshold −50 nT", fontsize=7, color=INK2)
    axes[1].annotate(f"min {o.dst.min():.0f} nT", (o.dst.idxmin(), o.dst.min()),
                     xytext=(10, 6), textcoords="offset points", fontsize=7.5, color=INK2)
    axes[1].set_ylabel("Dst (nT)")

    axes[2].bar(o.index, o.kp, width=0.11, color=C[3])
    axes[2].axhline(5, color=INK2, ls="--", lw=0.9)
    axes[2].text(t0, 5.2, "Kp = 5 (storm level)", fontsize=7, color=INK2)
    axes[2].set_ylabel("Kp"); axes[2].set_ylim(0, 9)

    for a in axes:
        a.grid(alpha=0.45); a.set_axisbelow(True)
        for sp in ("top", "right"):
            a.spines[sp].set_visible(False)
    fig.tight_layout()
    fig.savefig(f"{FIG}/fig08_storm_case_study.png"); plt.close(fig)
    print("fig08 done")


def main():
    d = nc.Dataset("data/processed/tec_cube.nc")
    times = pd.to_datetime(d["time"][:], unit="s")
    lats = np.asarray(d["lat"][:]); lons = np.asarray(d["lon"][:])
    tec = np.ma.filled(d["tec"][:], np.nan).astype("float32")
    fl = pd.read_parquet("data/interim/flashes_all.parquet")
    fl["utc"] = pd.to_datetime(fl.tai93, unit="s", origin="1993-01-01")
    res = pd.read_csv("reports/model_results.csv")
    imp = json.load(open("reports/feature_importance.json"))
    pred = pd.read_parquet("data/processed/predictions.parquet")
    omni = pd.read_parquet("data/processed/omni_drivers.parquet")

    fig_coverage(fl)
    fig_tec_snapshot(times, lats, lons, tec, fl)
    fig_models(res)
    fig_skill(res)
    fig_importance(imp)
    fig_scatter(pred)
    fig_physics(pred)
    fig_storm(times, lats, lons, tec, omni)
    print("\nall figures written to", FIG)


if __name__ == "__main__":
    main()
