"""Refit the best model (HistGradientBoosting) on train+val and save test-set predictions.

Model selection used the validation split; the final model is refit on train+val and
scored once on the untouched test period, which is standard practice.
"""
import sys, pickle, numpy as np, pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.pipeline import make_pipeline
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
sys.path.insert(0, "src")
from train import BASE_FEATURES, HORIZONS
import features as F

df = pd.read_parquet("data/processed/dataset.parquet").sort_values("time").reset_index(drop=True)
q2 = df.time.quantile(0.85)
out, models = [], {}

for h in HORIZONS:
    y_col, feats = f"y_tec_{h}", BASE_FEATURES + [f"cos_sza_{h}"]
    d = df[df[y_col].notna()]
    tr, te = d[d.time < q2], d[d.time >= q2]
    m = make_pipeline(SimpleImputer(strategy="median"),
                      HistGradientBoostingRegressor(max_iter=400, learning_rate=0.06,
                                                    random_state=0))
    m.fit(tr[feats], tr[y_col].values)
    p = m.predict(te[feats])
    models[h] = m
    rmse = float(np.sqrt(mean_squared_error(te[y_col], p)))
    base = float(np.sqrt(mean_squared_error(te[y_col], te.tec_now)))
    print(f"{h}: test RMSE={rmse:.3f}  persistence={base:.3f}  "
          f"skill={1-rmse/base:+.3f}  R2={r2_score(te[y_col], p):.3f}")
    out.append(pd.DataFrame({
        "time": te.time.values, "lat": te.lat.values, "lon": te.lon.values,
        "horizon": h, "y_true": te[y_col].values, "y_pred": p,
        "persistence": te.tec_now.values, "n_flashes": te.n_flashes.values,
        "kp": te.kp.values, "dst": te.dst.values,
    }))

pred = pd.concat(out, ignore_index=True)
# physics output layer, applied to both truth and forecast
for c in ("y_true", "y_pred"):
    pred[c.replace("y_", "") + "_fof2"] = F.tec_to_fof2(pred[c].values)
    pred[c.replace("y_", "") + "_muf"] = F.muf(F.tec_to_fof2(pred[c].values))
pred.to_parquet("data/processed/predictions.parquet", compression="zstd", index=False)
with open("data/processed/models.pkl", "wb") as f:
    pickle.dump(models, f)
print(f"\nwrote predictions.parquet rows={len(pred):,} and models.pkl")
