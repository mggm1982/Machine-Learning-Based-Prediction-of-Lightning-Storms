"""Parse IONEX global ionosphere maps (TEC) and interpolate to (lat, lon, time)."""
import numpy as np, pandas as pd, datetime as dt


def read_ionex(path):
    """Return (times, lats, lons, tec) where tec has shape (n_time, n_lat, n_lon) in TECU."""
    with open(path) as f:
        lines = f.read().splitlines()

    exponent, hdr_end = -1, 0
    for i, ln in enumerate(lines):
        label = ln[60:].strip()
        if label == "LAT1 / LAT2 / DLAT":
            lat1, lat2, dlat = (float(ln[x:x + 6]) for x in (2, 8, 14))
        elif label == "LON1 / LON2 / DLON":
            lon1, lon2, dlon = (float(ln[x:x + 6]) for x in (2, 8, 14))
        elif label == "EXPONENT":
            exponent = int(ln[:6])
        elif label == "END OF HEADER":
            hdr_end = i
            break

    lats = np.arange(lat1, lat2 + np.sign(dlat) * 1e-9, dlat)
    lons = np.arange(lon1, lon2 + np.sign(dlon) * 1e-9, dlon)
    scale = 10.0 ** exponent

    times, maps, i = [], [], hdr_end + 1
    while i < len(lines):
        if lines[i][60:].strip() != "START OF TEC MAP":
            i += 1
            continue
        i += 1
        e = [int(lines[i][x:x + 6]) for x in range(0, 36, 6)]
        # IONEX writes end-of-day midnight as hour 24; datetime needs 0 + one day
        roll = e[3] == 24
        if roll:
            e[3] = 0
        times.append(dt.datetime(*e) + (dt.timedelta(days=1) if roll else dt.timedelta(0)))
        i += 1
        grid = np.full((len(lats), len(lons)), np.nan)
        row = 0
        while lines[i][60:].strip() != "END OF TEC MAP":
            if lines[i][60:].strip() == "LAT/LON1/LON2/DLON/H":
                i += 1
                vals = []
                while len(vals) < len(lons):
                    vals += [int(lines[i][x:x + 5]) for x in range(0, 80, 5)
                             if lines[i][x:x + 5].strip()]
                    i += 1
                v = np.array(vals[:len(lons)], float)
                v[v == 9999] = np.nan          # IONEX fill value
                grid[row] = v * scale
                row += 1
            else:
                i += 1
        maps.append(grid)
        i += 1

    return pd.DatetimeIndex(times), lats, lons, np.array(maps)


def interp_tec(times, lats, lons, tec, when, lat, lon):
    """Trilinear interpolation of TEC (TECU) at given UTC time(s) and location(s)."""
    when = pd.DatetimeIndex(np.atleast_1d(when))
    lat, lon = np.atleast_1d(lat).astype(float), np.atleast_1d(lon).astype(float)
    lon = ((lon + 180) % 360) - 180

    epoch = np.datetime64("1970-01-01T00:00:00", "s")
    tsec = (times.values.astype("datetime64[s]") - epoch).astype("int64").astype(float)
    wsec = (when.values.astype("datetime64[s]") - epoch).astype("int64").astype(float)
    # fractional index along each axis (lats descend, so flip for searchsorted)
    ft = np.interp(wsec, tsec, np.arange(len(times)))
    fy = np.interp(lat, lats[::-1], np.arange(len(lats))[::-1])
    fx = np.interp(lon, lons, np.arange(len(lons)))

    out = np.empty(len(lat))
    for n, (t, y, x) in enumerate(zip(ft, fy, fx)):
        t0, y0, x0 = int(np.floor(t)), int(np.floor(y)), int(np.floor(x))
        t1 = min(t0 + 1, len(times) - 1)
        y1 = min(y0 + 1, len(lats) - 1)
        x1 = min(x0 + 1, len(lons) - 1)
        dt_, dy, dx = t - t0, y - y0, x - x0
        c = 0.0
        for ti, wt in ((t0, 1 - dt_), (t1, dt_)):
            for yi, wy in ((y0, 1 - dy), (y1, dy)):
                for xi, wx in ((x0, 1 - dx), (x1, dx)):
                    c += tec[ti, yi, xi] * wt * wy * wx
        out[n] = c
    return out
