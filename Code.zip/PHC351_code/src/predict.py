"""Interactive check: give a place and a time, get the TEC forecast and propagation numbers.

    python src/predict.py --lat 28.6 --lon 77.2 --time "2018-08-20 12:00"
    python src/predict.py --lat -15 --lon -60 --time "2018-06-15 18:30" --horizon 2h
    python src/predict.py --random 5

TEC history and space-weather drivers are looked up from the stored NASA data, so the time
must fall inside the processed window (2018-03-01 to 2018-09-01).
"""
import argparse, pickle, sys, warnings
import numpy as np, pandas as pd, netCDF4 as nc
sys.path.insert(0, "src")
import features as F
from train import BASE_FEATURES

warnings.filterwarnings("ignore")
LAGS = {"lag_15m": 1, "lag_30m": 2, "lag_1h": 4, "lag_2h": 8, "lag_3h": 12}
STEPS = {"1h": 4, "2h": 8, "6h": 24}


def build_row(times, lats, lons, tec, omni, med, when, lat, lon, horizon):
    """Assemble one feature row for a place and time, from the stored data."""
    it = int(np.argmin(np.abs(times - when)))
    iy = int(np.argmin(np.abs(lats - lat)))
    ix = int(np.argmin(np.abs(lons - (((lon + 180) % 360) - 180))))
    glat, glon = float(lats[iy]), float(lons[ix])

    r = dict(med)                      # lightning features default to training medians
    r["tec_now"] = float(tec[it, iy, ix])
    for name, lag in LAGS.items():
        r["tec_" + name] = float(tec[max(it - lag, 0), iy, ix])
        r["dtec_" + name] = r["tec_now"] - r["tec_" + name]

    ny, nx = len(lats), len(lons)
    nb = [tec[it, min(max(iy + dy, 0), ny - 1), (ix + dx) % nx]
          for dy in (-1, 0, 1) for dx in (-1, 0, 1) if (dy, dx) != (0, 0)]
    r["tec_neigh_mean"] = float(np.nanmean(nb))
    r["tec_neigh_grad"] = r["tec_now"] - r["tec_neigh_mean"]

    t64 = np.datetime64(times[it].to_pydatetime())
    r["lat"], r["lon"] = glat, glon
    r["abs_lat"] = abs(glat)
    r["maglat"] = float(F.magnetic_latitude(glat, glon))
    r["abs_maglat"] = abs(r["maglat"])
    r["cos_sza"] = float(F.solar_zenith_cos(t64, glat, glon))
    doy = times[it].dayofyear
    r["doy_sin"], r["doy_cos"] = np.sin(2*np.pi*doy/365.25), np.cos(2*np.pi*doy/365.25)
    lt = (times[it].hour + times[it].minute/60 + glon/15.0) % 24
    r["lt_sin"], r["lt_cos"] = np.sin(2*np.pi*lt/24), np.cos(2*np.pi*lt/24)

    drv = omni[omni.index <= times[it]].iloc[-1]
    for c in ("kp", "ap", "dst", "ae", "f107", "sunspot"):
        r[c] = float(drv[c])

    h = STEPS[horizon]
    r[f"cos_sza_{horizon}"] = float(F.solar_zenith_cos(
        t64 + np.timedelta64(h*15, "m"), glat, glon))

    actual = float(tec[it + h, iy, ix]) if it + h < len(times) else None
    return r, times[it], glat, glon, actual


def report(r, when, glat, glon, horizon, pred, actual):
    hz = {"1h": 1, "2h": 2, "6h": 6}[horizon]
    print(f"\n  grid cell      {glat:+.1f}°, {glon:+.1f}°   (nearest to request)")
    print(f"  epoch          {when:%Y-%m-%d %H:%M} UTC")
    print(f"  local time     {(when.hour + when.minute/60 + glon/15.0) % 24:.1f} h   "
          f"| magnetic lat {r['maglat']:+.1f}° | sun {'up' if r['cos_sza']>0 else 'down'}")
    print(f"  drivers        Kp {r['kp']:.1f}  Dst {r['dst']:+.0f} nT  F10.7 {r['f107']:.1f}")
    print(f"\n  TEC now                    {r['tec_now']:6.2f} TECU")
    print(f"  persistence (+{hz}h)         {r['tec_now']:6.2f} TECU   <- the baseline")
    print(f"  MODEL FORECAST (+{hz}h)      {pred:6.2f} TECU")
    if actual is not None:
        pe, me = abs(r["tec_now"]-actual), abs(pred-actual)
        print(f"  actual (+{hz}h)              {actual:6.2f} TECU")
        win = "model closer" if me < pe else "persistence closer"
        print(f"  error: model {me:.2f} vs persistence {pe:.2f}  ->  {win}")
    f = float(F.tec_to_fof2(pred)); m = float(F.muf(f))
    print(f"\n  derived propagation:  foF2 {f:5.2f} MHz | MUF(5°) {m:6.2f} MHz "
          f"| one-hop {F.hop_range_km():.0f} km")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--lat", type=float); p.add_argument("--lon", type=float)
    p.add_argument("--time", type=str)
    p.add_argument("--horizon", default="6h", choices=list(STEPS))
    p.add_argument("--random", type=int, default=0, help="sample N real test cases instead")
    a = p.parse_args()

    d = nc.Dataset("data/processed/tec_cube.nc")
    times = pd.to_datetime(d["time"][:], unit="s")
    lats, lons = np.asarray(d["lat"][:]), np.asarray(d["lon"][:])
    tec = np.ma.filled(d["tec"][:], np.nan).astype("float32")
    omni = pd.read_parquet("data/processed/omni_drivers.parquet")
    models = pickle.load(open("data/processed/models.pkl", "rb"))
    df = pd.read_parquet("data/processed/dataset.parquet")
    lightning = ["n_flashes","log_rad_mean","log_rad_max","log_rad_sum","fp_mean",
                 "log_fp_sum","dur_mean","ngroups_mean","log_nevents_sum","oblong_mean"]
    med = {c: float(df[c].median()) for c in lightning}

    if a.random:
        q2 = df.time.quantile(0.85)
        te = df[(df.time >= q2) & df[f"y_tec_{a.horizon}"].notna()]
        picks = te.sample(a.random, random_state=None)
        print(f"\n{a.random} random samples from the held-out test period, {a.horizon} ahead")
        for _, row in picks.iterrows():
            r, when, glat, glon, actual = build_row(
                times, lats, lons, tec, omni, med, row.time, row.lat, row.lon, a.horizon)
            feats = BASE_FEATURES + [f"cos_sza_{a.horizon}"]
            pred = float(models[a.horizon].predict(pd.DataFrame([r])[feats])[0])
            print("\n" + "-"*68)
            report(r, when, glat, glon, a.horizon, pred, actual)
        return

    if a.lat is None or a.lon is None or a.time is None:
        p.error("give --lat, --lon and --time, or use --random N")
    when = pd.Timestamp(a.time)
    if not (times[0] <= when <= times[-1]):
        print(f"\n  time must be between {times[0]} and {times[-1]} "
              f"(the processed NASA window)\n"); return

    r, w, glat, glon, actual = build_row(times, lats, lons, tec, omni, med,
                                         when, a.lat, a.lon, a.horizon)
    feats = BASE_FEATURES + [f"cos_sza_{a.horizon}"]
    pred = float(models[a.horizon].predict(pd.DataFrame([r])[feats])[0])
    print("\n" + "="*68)
    report(r, w, glat, glon, a.horizon, pred, actual)
    print("\n  note: lightning features set to training medians unless this cell had "
          "observed\n        flashes; the model leans on TEC and solar geometry anyway.")
    print("="*68 + "\n")


if __name__ == "__main__":
    main()
