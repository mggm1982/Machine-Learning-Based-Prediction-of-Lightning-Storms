"""Train and compare TEC-forecast models against a persistence baseline.

The split is chronological, never random: ionospheric fields are strongly autocorrelated in
space and time, so a random split would put near-identical samples in both train and test
and inflate every score.
"""
import sys, json, warnings
import numpy as np, pandas as pd
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor, HistGradientBoostingRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import xgboost as xgb

warnings.filterwarnings("ignore")
HORIZONS = ["1h", "2h", "6h"]

BASE_FEATURES = [
    "n_flashes", "log_rad_mean", "log_rad_max", "log_rad_sum", "fp_mean", "log_fp_sum",
    "dur_mean", "ngroups_mean", "log_nevents_sum", "oblong_mean",
    "tec_now", "tec_lag_15m", "tec_lag_30m", "tec_lag_1h", "tec_lag_2h", "tec_lag_3h",
    "dtec_lag_15m", "dtec_lag_30m", "dtec_lag_1h", "dtec_lag_2h", "dtec_lag_3h",
    "tec_neigh_mean", "tec_neigh_grad",
    "lat", "lon", "abs_lat", "maglat", "abs_maglat",
    "cos_sza", "doy_sin", "doy_cos", "lt_sin", "lt_cos",
    "kp", "ap", "dst", "ae", "f107", "sunspot",
]


def metrics(y, p):
    return {
        "rmse": float(np.sqrt(mean_squared_error(y, p))),
        "mae": float(mean_absolute_error(y, p)),
        "r2": float(r2_score(y, p)),
    }


def models():
    return {
        "Ridge": make_pipeline(SimpleImputer(strategy="median"), StandardScaler(), Ridge(alpha=1.0)),
        "RandomForest": make_pipeline(
            SimpleImputer(strategy="median"),
            RandomForestRegressor(n_estimators=300, min_samples_leaf=2,
                                  n_jobs=-1, random_state=0)),
        "HistGradBoost": make_pipeline(
            SimpleImputer(strategy="median"),
            HistGradientBoostingRegressor(max_iter=400, learning_rate=0.06, random_state=0)),
        "XGBoost": make_pipeline(
            SimpleImputer(strategy="median"),
            xgb.XGBRegressor(n_estimators=600, learning_rate=0.05, max_depth=7,
                             subsample=0.8, colsample_bytree=0.8, reg_lambda=1.0,
                             n_jobs=-1, random_state=0, tree_method="hist")),
        "MLP": make_pipeline(
            SimpleImputer(strategy="median"), StandardScaler(),
            MLPRegressor(hidden_layer_sizes=(128, 64), max_iter=600,
                         early_stopping=True, random_state=0)),
    }


def main():
    df = pd.read_parquet("data/processed/dataset.parquet").sort_values("time").reset_index(drop=True)
    # chronological 70 / 15 / 15
    q1, q2 = df.time.quantile(0.70), df.time.quantile(0.85)
    print(f"split boundaries: train < {q1}  val < {q2}  test >= {q2}\n")

    results, importances = [], {}
    for h in HORIZONS:
        y_col = f"y_tec_{h}"
        feats = BASE_FEATURES + [f"cos_sza_{h}"]
        d = df[df[y_col].notna()].copy()
        tr, va, te = d[d.time < q1], d[(d.time >= q1) & (d.time < q2)], d[d.time >= q2]
        Xtr, ytr = tr[feats], tr[y_col].values
        Xva, yva = va[feats], va[y_col].values
        Xte, yte = te[feats], te[y_col].values

        # baseline: tomorrow looks like now
        base = metrics(yte, te.tec_now.values)
        results.append(dict(horizon=h, model="Persistence", split="test", **base, skill=0.0))
        print(f"=== horizon {h}  train={len(tr):,} val={len(va):,} test={len(te):,}")
        print(f"  {'Persistence':<14} RMSE={base['rmse']:6.3f}  MAE={base['mae']:6.3f}  R2={base['r2']:6.3f}")

        for name, m in models().items():
            m.fit(Xtr, ytr)
            mt = metrics(yte, m.predict(Xte))
            mt["skill"] = 1 - mt["rmse"] / base["rmse"]
            results.append(dict(horizon=h, model=name, split="test", **mt))
            print(f"  {name:<14} RMSE={mt['rmse']:6.3f}  MAE={mt['mae']:6.3f}  "
                  f"R2={mt['r2']:6.3f}  skill={mt['skill']:+.3f}")
            if name == "XGBoost":
                booster = m.named_steps["xgbregressor"]
                importances[h] = dict(sorted(
                    zip(feats, booster.feature_importances_.astype(float)),
                    key=lambda kv: -kv[1]))
        print()

    res = pd.DataFrame(results)
    res.to_csv("reports/model_results.csv", index=False)
    with open("reports/feature_importance.json", "w") as f:
        json.dump(importances, f, indent=2)
    print("wrote reports/model_results.csv and reports/feature_importance.json")


if __name__ == "__main__":
    main()
