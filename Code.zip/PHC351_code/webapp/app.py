"""Small local web UI for checking the trained TEC forecast model.

Run:   .venv/bin/python webapp/app.py
Then:  open http://127.0.0.1:5000
"""
import pickle, sys, os, warnings
import numpy as np, pandas as pd, netCDF4 as nc
from flask import Flask, render_template, request, jsonify

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))
import features as F
from train import BASE_FEATURES

warnings.filterwarnings("ignore")
app = Flask(__name__)

LAGS = {"lag_15m": 1, "lag_30m": 2, "lag_1h": 4, "lag_2h": 8, "lag_3h": 12}
STEPS = {"1h": 4, "2h": 8, "6h": 24}

print("loading data and models ...")
_d = nc.Dataset(os.path.join(ROOT, "data/processed/tec_cube.nc"))
TIMES = pd.to_datetime(_d["time"][:], unit="s")
LATS = np.asarray(_d["lat"][:]); LONS = np.asarray(_d["lon"][:])
TEC = np.ma.filled(_d["tec"][:], np.nan).astype("float32")
OMNI = pd.read_parquet(os.path.join(ROOT, "data/processed/omni_drivers.parquet"))
MODELS = pickle.load(open(os.path.join(ROOT, "data/processed/models.pkl"), "rb"))
_df = pd.read_parquet(os.path.join(ROOT, "data/processed/dataset.parquet"))
LIGHTNING = ["n_flashes","log_rad_mean","log_rad_max","log_rad_sum","fp_mean",
             "log_fp_sum","dur_mean","ngroups_mean","log_nevents_sum","oblong_mean"]
MED = {c: float(_df[c].median()) for c in LIGHTNING}
TEST_START = _df.time.quantile(0.85)
print(f"ready: {TEC.shape} TEC grid, {TIMES[0]:%Y-%m-%d} to {TIMES[-1]:%Y-%m-%d}")


def predict(lat, lon, when, horizon):
    it = int(np.argmin(np.abs(TIMES - when)))
    iy = int(np.argmin(np.abs(LATS - lat)))
    ix = int(np.argmin(np.abs(LONS - (((lon + 180) % 360) - 180))))
    glat, glon = float(LATS[iy]), float(LONS[ix])

    r = dict(MED)
    r["tec_now"] = float(TEC[it, iy, ix])
    for name, lag in LAGS.items():
        r["tec_" + name] = float(TEC[max(it - lag, 0), iy, ix])
        r["dtec_" + name] = r["tec_now"] - r["tec_" + name]
    ny, nx = len(LATS), len(LONS)
    nb = [TEC[it, min(max(iy + dy, 0), ny - 1), (ix + dx) % nx]
          for dy in (-1, 0, 1) for dx in (-1, 0, 1) if (dy, dx) != (0, 0)]
    r["tec_neigh_mean"] = float(np.nanmean(nb))
    r["tec_neigh_grad"] = r["tec_now"] - r["tec_neigh_mean"]

    t64 = np.datetime64(TIMES[it].to_pydatetime())
    r["lat"], r["lon"], r["abs_lat"] = glat, glon, abs(glat)
    r["maglat"] = float(F.magnetic_latitude(glat, glon))
    r["abs_maglat"] = abs(r["maglat"])
    r["cos_sza"] = float(F.solar_zenith_cos(t64, glat, glon))
    doy = TIMES[it].dayofyear
    r["doy_sin"], r["doy_cos"] = np.sin(2*np.pi*doy/365.25), np.cos(2*np.pi*doy/365.25)
    lt = (TIMES[it].hour + TIMES[it].minute/60 + glon/15.0) % 24
    r["lt_sin"], r["lt_cos"] = np.sin(2*np.pi*lt/24), np.cos(2*np.pi*lt/24)
    drv = OMNI[OMNI.index <= TIMES[it]].iloc[-1]
    for c in ("kp","ap","dst","ae","f107","sunspot"):
        r[c] = float(drv[c])
    h = STEPS[horizon]
    r[f"cos_sza_{horizon}"] = float(F.solar_zenith_cos(
        t64 + np.timedelta64(h*15, "m"), glat, glon))

    feats = BASE_FEATURES + [f"cos_sza_{horizon}"]
    pred = float(MODELS[horizon].predict(pd.DataFrame([r])[feats])[0])
    actual = float(TEC[it + h, iy, ix]) if it + h < len(TIMES) else None

    fof2 = float(F.tec_to_fof2(pred)); muf = float(F.muf(fof2))
    out = dict(
        grid_lat=glat, grid_lon=glon,
        epoch=f"{TIMES[it]:%Y-%m-%d %H:%M}",
        target_epoch=f"{TIMES[it] + pd.Timedelta(minutes=15*h):%Y-%m-%d %H:%M}",
        local_time=round(lt, 1), sun_up=bool(r["cos_sza"] > 0),
        maglat=round(r["maglat"], 1),
        kp=r["kp"], dst=r["dst"], f107=r["f107"],
        tec_now=round(r["tec_now"], 2), persistence=round(r["tec_now"], 2),
        prediction=round(pred, 2),
        actual=round(actual, 2) if actual is not None else None,
        fof2=round(fof2, 2), muf=round(muf, 2),
        hop_km=round(float(F.hop_range_km())),
        in_test_period=bool(TIMES[it] >= TEST_START),
        horizon=horizon,
    )
    if actual is not None:
        me, pe = abs(pred - actual), abs(r["tec_now"] - actual)
        out.update(model_err=round(me, 2), persistence_err=round(pe, 2),
                   winner="model" if me < pe else "persistence")
    return out


@app.route("/")
def home():
    return render_template("index.html",
                           tmin=f"{TIMES[0]:%Y-%m-%dT%H:%M}",
                           tmax=f"{TIMES[-1]:%Y-%m-%dT%H:%M}")


@app.route("/api/predict")
def api_predict():
    try:
        lat = float(request.args["lat"]); lon = float(request.args["lon"])
        when = pd.Timestamp(request.args["time"])
        horizon = request.args.get("horizon", "6h")
        if horizon not in STEPS:
            return jsonify(error="horizon must be 1h, 2h or 6h"), 400
        if not (TIMES[0] <= when <= TIMES[-1]):
            return jsonify(error=f"time must be between {TIMES[0]:%Y-%m-%d} and "
                                 f"{TIMES[-1]:%Y-%m-%d}"), 400
        if not (-90 <= lat <= 90 and -180 <= lon <= 180):
            return jsonify(error="latitude -90..90, longitude -180..180"), 400
        return jsonify(predict(lat, lon, when, horizon))
    except Exception as e:
        return jsonify(error=f"{type(e).__name__}: {e}"), 400


@app.route("/api/random")
def api_random():
    horizon = request.args.get("horizon", "6h")
    te = _df[(_df.time >= TEST_START) & _df[f"y_tec_{horizon}"].notna()]
    row = te.sample(1).iloc[0]
    return jsonify(predict(float(row.lat), float(row.lon), row.time, horizon))


if __name__ == "__main__":
    app.run(debug=False, port=5000)
